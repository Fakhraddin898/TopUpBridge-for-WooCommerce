<?php
/**
 * Plugin Name: FX TopUpEpin for WooCommerce
 * Description: TopUpEpin B2B API интеграция – профиль тест, синхронизация продуктов с WooCommerce, изображения по категориям, поля игровой информации в checkout и отправка заказов в TopUpEpin API. Также есть функция очистки продуктов TopUpEpin.
 * Author: Faxri & ChatGPT
 * Version: 1.9.3
 * Text Domain: fx-topupepin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * === КОНФИГУРАЦИЯ ===
 */

function fx_topupepin_default_base_url() {
    return 'https://topupepin.com/api/v1';
}

/**
 * === IPv4 ФИЛЬТРЫ ===
 */

/**
 * Фильтр для cURL чтобы использовать IPv4
 */
function fx_topupepin_curl_ipv4($handle, $r, $url) {
    // Принудительно используем IPv4
    curl_setopt($handle, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    return $handle;
}

/**
 * Фильтр для потоковых сокетов чтобы использовать IPv4
 */
function fx_topupepin_stream_ipv4($args) {
    if (!isset($args['stream_context'])) {
        $args['stream_context'] = array();
    }
    $args['stream_context']['socket'] = array(
        'bindto' => '0.0.0.0:0',  // Используем IPv4
    );
    return $args;
}

/**
 * TopUpEpin продукта изображение удалить (если используется только для этого продукта)
 */
function fx_topupepin_delete_product_image( $product_id ) {
    // Найти thumbnail ID продукта
    $thumb_id = get_post_thumbnail_id( $product_id );
    
    if ( ! $thumb_id ) {
        return false;
    }
    
    // Проверить в метаданных изображения, является ли оно TopUpEpin
    $image_source = get_post_meta( $product_id, '_fx_topupepin_image_src', true );
    
    if ( ! $image_source ) {
        // Если изображение не из TopUpEpin, не удаляем
        return false;
    }
    
    // Проверить, используется ли это изображение где-либо еще
    $args = array(
        'post_type' => 'product',
        'post_status' => 'any',
        'post__not_in' => array( $product_id ),
        'meta_query' => array(
            array(
                'key' => '_thumbnail_id',
                'value' => $thumb_id,
                'compare' => '='
            )
        ),
        'fields' => 'ids',
        'posts_per_page' => 1
    );
    
    $other_usage = get_posts( $args );
    
    // Если изображение не используется в других продуктах, удалить
    if ( empty( $other_usage ) ) {
        // Сначала удалить связь thumbnail с продуктом
        delete_post_meta( $product_id, '_thumbnail_id' );
        delete_post_meta( $product_id, '_fx_topupepin_image_src' );
        delete_post_meta( $product_id, '_fx_topupepin_custom_image_url' );
        
        // Затем удалить attachment
        $deleted = wp_delete_attachment( $thumb_id, true );
        
        fx_topupepin_log( 'Изображение удалено: продукт ' . $product_id . ', attachment ' . $thumb_id );
        
        return $deleted !== false;
    }
    
    return false;
}

/**
 * === CRON – КАЖДЫЕ 30 МИНУТ АВТО СИНХРОНИЗАЦИЯ ===
 */

// 30-минутный интервал добавить
add_filter( 'cron_schedules', 'fx_topupepin_cron_schedules' );
function fx_topupepin_cron_schedules( $schedules ) {
    if ( ! isset( $schedules['fx_topupepin_30min'] ) ) {
        $schedules['fx_topupepin_30min'] = array(
            'interval' => 30 * 60, // 30 минут
            'display'  => __( 'Every 30 Minutes (TopUpEpin)', 'fx-topupepin' ),
        );
    }
    return $schedules;
}

// Активация времени cron event
register_activation_hook( __FILE__, 'fx_topupepin_activate' );
function fx_topupepin_activate() {
    if ( ! wp_next_scheduled( 'fx_topupepin_cron_sync' ) ) {
        // Первый sync через 5 минут, затем каждые 30 минут
        wp_schedule_event( time() + 300, 'fx_topupepin_30min', 'fx_topupepin_cron_sync' );
    }
}

// Деактивация времени cron event удалить
register_deactivation_hook( __FILE__, 'fx_topupepin_deactivate' );
function fx_topupepin_deactivate() {
    $timestamp = wp_next_scheduled( 'fx_topupepin_cron_sync' );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, 'fx_topupepin_cron_sync' );
    }
}

// Cron callback – каждые 30 минут синхронизировать продукты
add_action( 'fx_topupepin_cron_sync', 'fx_topupepin_cron_sync_callback' );
function fx_topupepin_cron_sync_callback() {
    if ( ! class_exists( 'WC_Product' ) ) {
        return;
    }

    // Авто-синхронизация: каждые 30 минут весь каталог с 1-й страницы до конца
    // страница за страницей (batch) обрабатывается. На каждом шаге используется
    // функция fx_topupepin_sync_products_step().
    $limit   = 100; // каждый шаг максимальное количество услуг
    $page    = 1;
    $maxloop = 500; // для безопасности предел (не более 500 страниц)

    $total_count   = 0;
    $total_created = 0;
    $total_updated = 0;
    $loops         = 0;

    while ( $page > 0 && $loops < $maxloop ) {
        $result = fx_topupepin_sync_products_step( $page, $limit );

        if ( is_wp_error( $result ) ) {
            fx_topupepin_log( 'CRON FULL STEP SYNC ERROR (page ' . $page . '): ' . $result->get_error_message() );
            break;
        }

        $count   = isset( $result['count'] )   ? (int) $result['count']   : 0;
        $created = isset( $result['created'] ) ? (int) $result['created'] : 0;
        $updated = isset( $result['updated'] ) ? (int) $result['updated'] : 0;

        $total_count   += $count;
        $total_created += $created;
        $total_updated += $updated;

        $loops++;
        $page++;

        if ( empty( $result['has_more'] ) ) {
            // Нет больше страниц – останавливаем цикл
            break;
        }
    }

    fx_topupepin_log( 'CRON FULL STEP SYNC OK: ' . wp_json_encode( array(
        'limit'         => $limit,
        'loops'         => $loops,
        'total_count'   => $total_count,
        'total_created' => $total_created,
        'total_updated' => $total_updated,
    ) ) );
}

/**
 * === LOG ФУНКЦИЯ ===
 */

function fx_topupepin_log( $message ) {
    $debug = (int) get_option( 'fx_topupepin_debug', 0 );
    if ( ! $debug ) {
        return;
    }

    $upload_dir = wp_upload_dir();
    $file       = trailingslashit( $upload_dir['basedir'] ) . 'fx-topupepin.log';

    $line = '[' . date( 'Y-m-d H:i:s' ) . '] ' . $message . PHP_EOL;
    file_put_contents( $file, $line, FILE_APPEND );
}

/**
 * === ОСНОВНАЯ REQUEST ФУНКЦИЯ ===
 */

function fx_topupepin_request( $endpoint, $params = array() ) {
    $base_url = rtrim( get_option( 'fx_topupepin_api_base', fx_topupepin_default_base_url() ), '/' );
    $api_key  = trim( get_option( 'fx_topupepin_api_key', '' ) );

    if ( empty( $api_key ) ) {
        return new WP_Error( 'no_api_key', 'TopUpEpin API key не установлен.' );
    }

    $body = array_merge(
        array( 'api_key' => $api_key ),
        (array) $params
    );

    $url = $base_url . '/' . ltrim( $endpoint, '/' );

    $args = array(
        'timeout' => 30,
        'body'    => $body,
        'headers' => array(
            'api_key'    => $api_key,
            'Accept'     => 'application/json,text/*,*/*',
            'User-Agent' => 'ValyutaMobileBot/1.0 (+https://valyutamobile.com)',
        ),
    );

    fx_topupepin_log( 'REQUEST ' . $url . ' | ' . wp_json_encode( $body ) );

    // Добавляем фильтры для использования IPv4
    add_filter( 'http_api_curl', 'fx_topupepin_curl_ipv4', 10, 3 );
    add_filter( 'http_request_args', 'fx_topupepin_stream_ipv4', 10, 1 );

    $response = wp_remote_post( $url, $args );

    // Удаляем фильтры после запроса
    remove_filter( 'http_api_curl', 'fx_topupepin_curl_ipv4', 10 );
    remove_filter( 'http_request_args', 'fx_topupepin_stream_ipv4', 10 );

    if ( is_wp_error( $response ) ) {
        fx_topupepin_log( 'HTTP ERROR: ' . $response->get_error_message() );
        return $response;
    }

    $code = wp_remote_retrieve_response_code( $response );
    $raw  = wp_remote_retrieve_body( $response );

    fx_topupepin_log( 'RESPONSE [' . $code . ']: ' . $raw );

    $data = json_decode( $raw, true );
    if ( null === $data ) {
        return new WP_Error( 'bad_json', 'TopUpEpin JSON ответ нечитаем: ' . $raw );
    }

    return $data;
}

/**
 * === ENDPOINT ПОМОЩНИКИ ===
 */

function fx_topupepin_get_profile() {
    return fx_topupepin_request( 'profile' );
}

function fx_topupepin_get_products( $args = array() ) {
    // Новый get-services endpoint (вместо старого /service)
    $args = (array) $args;

    // Limit и page не указаны – используем максимум
    if ( ! isset( $args['limit'] ) ) {
        $args['limit'] = 500; // по API max 500
    }
    if ( ! isset( $args['page'] ) ) {
        $args['page'] = 1;
    }

    return fx_topupepin_request( 'get-services', $args );
}

/**
 * TRY → AZN текущий курс возвращает.
 * - Если auto-курс деактивирован – используется manual курс.
 * - Если auto-курс активен – берется с ExchangeRate-API и кэшируется.
 */
function fx_topupepin_get_current_rate_try_azn() {
    // Manual курс – fallback или начальное значение
    $manual_rate = (float) get_option( 'fx_topupepin_rate_usd_azn', 1.7 );
    if ( $manual_rate <= 0 ) {
        $manual_rate = 1;
    }

    // Auto-курс деактивирован – сразу возвращаем manual
    $auto = (int) get_option( 'fx_topupepin_rate_auto', 0 );
    if ( ! $auto ) {
        return $manual_rate;
    }

    // Если в кэше есть готовый курс – используем
    $cached = get_transient( 'fx_topupepin_rate_try_azn' );
    if ( $cached !== false ) {
        return (float) $cached;
    }

    // ExchangeRate-API KEY (НОВОЕ ПОЛЕ)
    $api_key = trim( get_option( 'fx_topupepin_rate_api_key', '' ) );
    if ( $api_key === '' ) {
        fx_topupepin_log( 'RATE ERROR: ExchangeRate-API key пустой, используется manual курс.' );
        return $manual_rate;
    }

    // Интервал обновления (минуты → секунды)
    $interval_minutes = (int) get_option( 'fx_topupepin_rate_update_interval', 60 ); // по умолчанию 60 мин
    if ( $interval_minutes < 5 ) {
        $interval_minutes = 5;
    }
    if ( $interval_minutes > 1440 ) { // не более 24 часов
        $interval_minutes = 1440;
    }
    $ttl = $interval_minutes * MINUTE_IN_SECONDS;

    // ExchangeRate-API URL: https://v6.exchangerate-api.com/v6/YOUR_KEY/latest/TRY
    $url = sprintf(
        'https://v6.exchangerate-api.com/v6/%s/latest/TRY',
        rawurlencode( $api_key )
    );

    // Добавляем фильтры для использования IPv4
    add_filter( 'http_api_curl', 'fx_topupepin_curl_ipv4', 10, 3 );
    add_filter( 'http_request_args', 'fx_topupepin_stream_ipv4', 10, 1 );

    $response = wp_remote_get(
        $url,
        array(
            'timeout' => 15,
            'headers' => array(
                'Accept'     => 'application/json',
                'User-Agent' => 'ValyutaMobileTopUpEpin/1.0',
            ),
        )
    );

    // Удаляем фильтры после запроса
    remove_filter( 'http_api_curl', 'fx_topupepin_curl_ipv4', 10 );
    remove_filter( 'http_request_args', 'fx_topupepin_stream_ipv4', 10 );

    if ( is_wp_error( $response ) ) {
        fx_topupepin_log( 'RATE HTTP ERROR: ' . $response->get_error_message() );
        return $manual_rate;
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = wp_remote_retrieve_body( $response );
    $data = json_decode( $body, true );

    // Ожидаемая структура:
    // { "result":"success", "conversion_rates": { "AZN": 0.04, ... } }
    if (
        $code !== 200 ||
        ! is_array( $data ) ||
        ( isset( $data['result'] ) && $data['result'] !== 'success' ) ||
        empty( $data['conversion_rates']['AZN'] )
    ) {
        fx_topupepin_log( 'RATE BAD RESPONSE: ' . $body );
        return $manual_rate;
    }

    $rate = (float) $data['conversion_rates']['AZN'];
    if ( $rate <= 0 ) {
        fx_topupepin_log( 'RATE VALUE <= 0, BODY: ' . $body );
        return $manual_rate;
    }

    // Кэш + запись в manual курс поле
    set_transient( 'fx_topupepin_rate_try_azn', $rate, $ttl );
    update_option( 'fx_topupepin_rate_usd_azn', $rate );

    fx_topupepin_log(
        'RATE UPDATED (ExchangeRate-API): TRY->AZN = ' . $rate .
        ' | interval=' . $interval_minutes . 'm'
    );

    return $rate;
}

/**
 * Manual: обновить курс (удалить transient и сразу получить с API).
 * Кнопка "Обновить курс вручную" в админке вызывает это.
 */
function fx_topupepin_refresh_rate_now() {
    delete_transient( 'fx_topupepin_rate_try_azn' );
    return fx_topupepin_get_current_rate_try_azn();
}

/**
 * Для данной категории возвращает маржу в процентах.
 * Если для категории отдельная маржа не установлена – возвращает общую маржу.
 */
function fx_topupepin_get_category_markup_percent( $category ) {
    $global_markup = (float) get_option( 'fx_topupepin_markup_percent', 30 );
    $map           = get_option( 'fx_topupepin_category_markups', array() );

    if ( ! is_array( $map ) ) {
        $map = array();
    }

    if ( ! $category ) {
        return $global_markup;
    }

    $slug = sanitize_title( (string) $category );

    if ( $slug && isset( $map[ $slug ] ) && $map[ $slug ] !== '' ) {
        return (float) $map[ $slug ];
    }

    return $global_markup;
}

/**
 * Расчет цены: API price → AZN
 * $category – TopUpEpin category (например: "PUBG Mobile", "Mobile Legends" и т.д.)
 */
function fx_topupepin_calc_wc_price( $api_price, $category = '' ) {
    // TRY → AZN курс: auto + fallback manual
    $rate = fx_topupepin_get_current_rate_try_azn();

    $markup = fx_topupepin_get_category_markup_percent( $category );

    $price_azn = (float) $api_price * $rate * ( 1 + ( $markup / 100 ) );
    return round( $price_azn, 2 );
}

/**
 * Категория → карта изображений прочитать
 */

function fx_topupepin_get_category_image_map() {
    $raw = get_option( 'fx_topupepin_category_image_map', '' );
    $map = array();

    if ( ! $raw ) {
        return $map;
    }

    $lines = preg_split( '/\r\n|\r|\n/', $raw );
    foreach ( $lines as $line ) {
        $line = trim( $line );
        if ( $line === '' || strpos( $line, '|' ) === false ) {
            continue;
        }
        list( $cat, $url ) = array_map( 'trim', explode( '|', $line, 2 ) );
        if ( $cat && $url ) {
            $map[ $cat ] = esc_url_raw( $url );
        }
    }

    return $map;
}

/**
 * По имени категории найти URL изображения:
 * - сначала прямой ключ (старое поведение)
 * - потом case-insensitive
 * - потом slug (mobile-legends)
 * - потом частичное совпадение (Mobile Legends ↔ Mobile Legends Bang Bang)
 */
function fx_topupepin_get_image_for_category( $category, $cat_image_map ) {
    if ( ! $category || empty( $cat_image_map ) ) {
        return '';
    }

    $category = trim( (string) $category );
    if ( $category === '' ) {
        return '';
    }

    $cat_slug = sanitize_title( $category );

    // 1) Старое поведение: прямым ключом
    if ( isset( $cat_image_map[ $category ] ) && $cat_image_map[ $category ] ) {
        return $cat_image_map[ $category ];
    }

    // 2) Case-insensitive полное имя
    foreach ( $cat_image_map as $key => $url ) {
        if ( ! $url ) {
            continue;
        }
        if ( strcasecmp( $key, $category ) === 0 ) {
            return $url;
        }
    }

    // 3) По слагам полное совпадение
    foreach ( $cat_image_map as $key => $url ) {
        if ( ! $url ) {
            continue;
        }
        if ( $cat_slug && sanitize_title( $key ) === $cat_slug ) {
            return $url;
        }
    }

    // 4) Частичное совпадение – по имени
    foreach ( $cat_image_map as $key => $url ) {
        if ( ! $url ) {
            continue;
        }
        if (
            stripos( $category, $key ) !== false ||
            stripos( $key, $category ) !== false
        ) {
            return $url;
        }
    }

    // 5) Частичное совпадение – по слагу
    foreach ( $cat_image_map as $key => $url ) {
        if ( ! $url ) {
            continue;
        }
        $key_slug = sanitize_title( $key );
        if ( ! $cat_slug || ! $key_slug ) {
            continue;
        }

        if (
            $key_slug === $cat_slug ||
            strpos( $cat_slug, $key_slug ) !== false ||
            strpos( $key_slug, $cat_slug ) !== false
        ) {
            return $url;
        }
    }

    return '';
}

/**
 * === NEW: Категория → short description карта ===
 */

/**
 * Категория → short description карта прочитать
 */
function fx_topupepin_get_category_desc_map() {
    $raw = get_option( 'fx_topupepin_category_desc_map', '' );
    $map = array();

    if ( ! $raw ) {
        return $map;
    }

    $lines = preg_split( '/\r\n|\r|\n/', $raw );
    foreach ( $lines as $line ) {
        $line = trim( $line );
        if ( $line === '' || strpos( $line, '|' ) === false ) {
            continue;
        }
        list( $cat, $text ) = array_map( 'trim', explode( '|', $line, 2 ) );
        if ( $cat && $text ) {
            $map[ $cat ] = $text;
        }
    }

    return $map;
}

/**
 * По имени категории найти short description:
 * - прямой ключ
 * - case-insensitive
 * - slug
 * - частичное совпадение
 */
function fx_topupepin_get_desc_for_category( $category, $cat_desc_map ) {
    if ( ! $category || empty( $cat_desc_map ) ) {
        return '';
    }

    $category = trim( (string) $category );
    if ( $category === '' ) {
        return '';
    }

    $cat_slug = sanitize_title( $category );

    // 1) Прямой ключ
    if ( isset( $cat_desc_map[ $category ] ) && $cat_desc_map[ $category ] ) {
        return $cat_desc_map[ $category ];
    }

    // 2) Case-insensitive полное имя
    foreach ( $cat_desc_map as $key => $text ) {
        if ( ! $text ) {
            continue;
        }
        if ( strcasecmp( $key, $category ) === 0 ) {
            return $text;
        }
    }

    // 3) По слагам полное совпадение
    foreach ( $cat_desc_map as $key => $text ) {
        if ( ! $text ) {
            continue;
        }
        if ( $cat_slug && sanitize_title( $key ) === $cat_slug ) {
            return $text;
        }
    }

    // 4) Частичное совпадение – по имени
    foreach ( $cat_desc_map as $key => $text ) {
        if ( ! $text ) {
            continue;
        }
        if (
            stripos( $category, $key ) !== false ||
            stripos( $key, $category ) !== false
        ) {
            return $text;
        }
    }

    // 5) Частичное совпадение – по слагу
    foreach ( $cat_desc_map as $key => $text ) {
        if ( ! $text ) {
            continue;
        }
        $key_slug = sanitize_title( $key );
        if ( ! $cat_slug || ! $key_slug ) {
            continue;
        }

        if (
            $key_slug === $cat_slug ||
            strpos( $cat_slug, $key_slug ) !== false ||
            strpos( $key_slug, $cat_slug ) !== false
        ) {
            return $text;
        }
    }

    return '';
}

/**
 * Для продукта изображение из URL загрузить и назначить как thumbnail
 *
 * $force = true – manual вызов (например, из meta box),
 * автоматическая блокировка проверки пропускается.
 */
function fx_topupepin_set_product_image_from_url( $product_id, $image_url, $force = false ) {
    if ( ! $image_url || ! $product_id ) {
        return;
    }

    // Если admin для продукта manual URL изображения указал – не обновлять автоматически
    if ( ! $force ) {
        $manual = get_post_meta( $product_id, '_fx_topupepin_custom_image_url', true );
        if ( ! empty( $manual ) ) {
            fx_topupepin_log( 'Изображение не обновляется автоматически (manual изображение есть): продукт ' . $product_id );
            return;
        }
    }

    // Этот URL уже был назначен ранее – не загружать повторно
    $prev_src = get_post_meta( $product_id, '_fx_topupepin_image_src', true );
    if ( $prev_src === $image_url && has_post_thumbnail( $product_id ) ) {
        fx_topupepin_log( 'Изображение уже назначено, повторно не загружается: ' . $image_url );
        return;
    }

    if ( ! function_exists( 'media_sideload_image' ) ) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
    }

    $attachment_id = media_sideload_image( $image_url, $product_id, null, 'id' );

    if ( is_wp_error( $attachment_id ) ) {
        fx_topupepin_log( 'Изображение не загружено: ' . $image_url . ' | ' . $attachment_id->get_error_message() );
        return;
    }

    set_post_thumbnail( $product_id, $attachment_id );
    update_post_meta( $product_id, '_fx_topupepin_image_src', esc_url_raw( $image_url ) );
    fx_topupepin_log( 'Изображение назначено: продукт ' . $product_id . ' → ' . $image_url );
}

/**
 * WooCommerce категорию назначить (product_cat)
 */

function fx_topupepin_assign_category( $product_id, $category_name ) {
    if ( ! $category_name ) {
        return;
    }

    $term = term_exists( $category_name, 'product_cat' );

    if ( ! $term ) {
        $term = wp_insert_term( $category_name, 'product_cat' );
    }

    if ( is_wp_error( $term ) ) {
        return;
    }

    $term_id = is_array( $term ) ? $term['term_id'] : $term;

    wp_set_object_terms( $product_id, (int) $term_id, 'product_cat' );
}

/**
 * TopUpEpin продукт ли это проверить
 */
function fx_topupepin_is_topupepin_product( $product_id ) {
    return (bool) get_post_meta( $product_id, '_fx_topupepin_product_id', true );
}

/**
 * TopUpEpin продукт категории
 */
function fx_topupepin_get_topupepin_categories() {
    $products = get_posts( array(
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
        'meta_key'       => '_fx_topupepin_product_id',
        'fields'         => 'ids',
    ) );

    $cats = array();

    if ( ! empty( $products ) ) {
        foreach ( $products as $product_id ) {
            $terms = get_the_terms( $product_id, 'product_cat' );
            if ( empty( $terms ) || is_wp_error( $terms ) ) {
                continue;
            }
            foreach ( $terms as $term ) {
                $cats[ $term->slug ] = $term;
            }
        }
    }

    return array_values( $cats );
}

/**
 * === MANUAL ИЗОБРАЖЕНИЕ METABOX (СТРАНИЦА ПРОДУКТА) ===
 * Здесь admin для каждого TopUpEpin продукта может указать свой URL изображения.
 * Если это поле не пустое → при синхронизации изображение автоматически не изменится.
 */

// Админке media uploader скрипт
// Админке media uploader + admin JS
add_action( 'admin_enqueue_scripts', 'fx_topupepin_admin_enqueue_media' );
function fx_topupepin_admin_enqueue_media( $hook ) {

    /**
     * === 1) Страница редактирования продукта (manual изображение metabox) ===
     */
    if ( $hook === 'post-new.php' || $hook === 'post.php' ) {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'product' ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_script( 'jquery' );

        $js_product = <<<'JS'
jQuery(function($){
    var frame;
    $(document).on('click', '#fx_topupepin_choose_image', function(e){
        e.preventDefault();

        var $input = $('#fx_topupepin_custom_image_url');

        if (frame) {
            frame.open();
            return;
        }

        frame = wp.media({
            title: 'Выберите изображение',
            button: { text: 'Использовать это изображение' },
            multiple: false
        });

        frame.on('select', function(){
            var attachment = frame.state().get('selection').first().toJSON();
            if (attachment.url) {
                $input.val(attachment.url).trigger('change');
            }
        });

        frame.open();
    });
});
JS;
        wp_add_inline_script( 'jquery', $js_product );
        return;
    }

    /**
     * === 2) Страница настроек TopUpEpin (визуальная карта категория-изображение + "выбрать все") ===
     */
    if ( $hook === 'toplevel_page_fx-topupepin' ) {
        wp_enqueue_media();
        wp_enqueue_script( 'jquery' );

        $js_admin = <<<'JS'
jQuery(function($){

    // --- Визуальный редактор для карты изображений категорий ---
    var $textarea = $('#fx_topupepin_category_image_map');
    var $builder  = $('#fx_topupepin_category_image_builder');

    if ($textarea.length && $builder.length && typeof wp !== 'undefined' && wp.media) {

        // Старый textarea скроем (остается как fallback)
        $textarea.addClass('fx-topupepin-hidden');

        var tableHtml =
            '<table class="widefat striped fx-topupepin-image-table">' +
                '<thead>' +
                    '<tr>' +
                        '<th style="width:40%;">Категория</th>' +
                        '<th>Изображение</th>' +
                        '<th style="width:60px;"></th>' +
                    '</tr>' +
                '</thead>' +
                '<tbody></tbody>' +
            '</table>' +
            '<p><button type="button" class="button" id="fx_topupepin_add_image_row">Добавить новую строку</button></p>';

        $builder.html(tableHtml);

        var $tbody = $builder.find('tbody');

        function renderPreview($row, url) {
            var html;
            if (url) {
                html = '<div class="fx-topupepin-preview"><img src="' + url + '" alt=""></div>';
            } else {
                html = '<div class="fx-topupepin-preview fx-empty">Изображение не выбрано</div>';
            }
            $row.find('.fx-topupepin-preview-wrapper').html(html);
        }

        function addRow(cat, url) {
            var row = $(  
                '<tr>' +
                    '<td>' +
                        '<input type="text" class="regular-text fx-cat-name" placeholder="Например: PUBG Mobile" />' +
                    '</td>' +
                    '<td>' +
                        '<div class="fx-topupepin-preview-wrapper"></div>' +
                        '<div class="fx-topupepin-image-actions">' +
                            '<input type="hidden" class="fx-topupepin-image-url" />' +
                            '<button type="button" class="button fx-topupepin-choose-cat-image">Выбрать изображение</button>' +
                        '</div>' +
                    '</td>' +
                    '<td class="fx-topupepin-row-actions">' +
                        '<button type="button" class="button-link-delete fx-topupepin-remove-row">Удалить</button>' +
                    '</td>' +
                '</tr>'
            );

            row.find('.fx-cat-name').val(cat || '');
            row.find('.fx-topupepin-image-url').val(url || '');
            renderPreview(row, url || '');

            $tbody.append(row);
        }

        // Существующий текст разбить: "Категория|URL"
        var raw = $textarea.val();
        if (raw) {
            raw.split(/\r?\n/).forEach(function(line){
                line = $.trim(line);
                if (!line || line.indexOf('|') === -1) {
                    return;
                }
                var parts = line.split('|');
                var cat = $.trim(parts[0] || '');
                var url = $.trim(parts[1] || '');
                if (cat || url) {
                    addRow(cat, url);
                }
            });
        }

        // Если ничего нет – одна пустая строка
        if (!$tbody.find('tr').length) {
            addRow('', '');
        }

        var mediaFrame;

        // Кнопка выбора изображения
        $builder.on('click', '.fx-topupepin-choose-cat-image', function(e){
            e.preventDefault();

            var $btn = $(this);
            var $row = $btn.closest('tr');

            if (mediaFrame) {
                mediaFrame.off('select');
            }

            mediaFrame = wp.media({
                title: 'Выберите изображение',
                button: { text: 'Использовать это изображение' },
                multiple: false
            });

            mediaFrame.on('select', function(){
                var attachment = mediaFrame.state().get('selection').first().toJSON();
                if (!attachment || !attachment.url) {
                    return;
                }
                $row.find('.fx-topupepin-image-url').val(attachment.url);
                renderPreview($row, attachment.url);
            });

            mediaFrame.open();
        });

        // Новая строка
        $('#fx_topupepin_add_image_row').on('click', function(e){
            e.preventDefault();
            addRow('', '');
        });

        // Удалить строку
        $builder.on('click', '.fx-topupepin-remove-row', function(e){
            e.preventDefault();

            var $row = $(this).closest('tr');

            if ($tbody.find('tr').length <= 1) {
                // Если последняя строка – просто очистим
                $row.find('.fx-cat-name').val('');
                $row.find('.fx-topupepin-image-url').val('');
                renderPreview($row, '');
            } else {
                $row.remove();
            }
        });

        // При отправке формы – таблицу снова в textarea записать
        $('form[action="options.php"]').on('submit.fxTopupepin', function(){
            var lines = [];

            $tbody.find('tr').each(function(){
                var cat = $.trim($(this).find('.fx-cat-name').val() || '');
                var url = $.trim($(this).find('.fx-topupepin-image-url').val() || '');

                if (cat && url) {
                    lines.push(cat + '|' + url);
                }
            });

            $textarea.val(lines.join("\n"));
        });
    }

    // --- "Выбрать все" чекбоксы ---
    $('#fx_topupepin_select_all_cats').on('change', function(){
        var checked = $(this).is(':checked');
        $('input[name="fx_topupepin_delete_cats[]"]').prop('checked', checked);
    });

    $('#fx_topupepin_select_all_products').on('change', function(){
        var checked = $(this).is(':checked');
        $('input[name="fx_topupepin_delete_products[]"]').prop('checked', checked);
    });

});
JS;
        wp_add_inline_script( 'jquery', $js_admin );
        // === NEW: Batch sync JS (admin AJAX) ===
        $sync_nonce = wp_create_nonce( 'fx_topupepin_sync_step' );

        wp_localize_script( 'jquery', 'fx_topupepin_sync_cfg', array(
            'nonce' => $sync_nonce,
            'limit' => 100, // сколько услуг обрабатывать за один шаг
        ) );

        $js_sync = <<<'JSSYNC'
jQuery(function($){

    function fxTopupepinRunSync(page){
        page = page || 1;

        var $btn    = $('#fx_topupepin_sync_btn');
        var $status = $('#fx_topupepin_sync_status');

        $btn.prop('disabled', true);
        $status.addClass('fx-topupepin-pre').css({
            'background':'#0f172a',
            'color':'#e5e7eb',
            'padding':'10px',
            'border-radius':'6px',
            'margin-top':'8px',
            'max-height':'260px',
            'overflow':'auto',
            'font-size':'12px',
            'white-space':'pre-wrap'
        });

        $.post(ajaxurl, {
            action: 'fx_topupepin_sync_step',
            nonce:  fx_topupepin_sync_cfg.nonce,
            page:   page,
            limit:  fx_topupepin_sync_cfg.limit
        }).done(function(resp){
            if (!resp || !resp.success) {
                var msg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Неизвестная ошибка';
                $status.append("\nОшибка: " + msg);
                $btn.prop('disabled', false);
                return;
            }

            var d = resp.data;
            $status.append(
                "\nСтраница " + d.page +
                " → услуг: " + d.count +
                ", создано: " + d.created +
                ", обновлено: " + d.updated
            );

            if (d.has_more) {
                setTimeout(function(){
                    fxTopupepinRunSync(d.page + 1);
                }, 400);
            } else {
                $status.append("\n\n✔ Синхронизация завершена.");
                $btn.prop('disabled', false);
            }

        }).fail(function(){
            $status.append("\nAJAX запрос не удался.");
            $btn.prop('disabled', false);
        });
    }

    $(document).on('click', '#fx_topupepin_sync_btn', function(e){
        e.preventDefault();
        var $status = $('#fx_topupepin_sync_status');
        $status.text("Синхронизация начата...");
        fxTopupepinRunSync(1);
    });

});
JSSYNC;
        wp_add_inline_script( 'jquery', $js_sync );

    }
}

// Metabox добавить
add_action( 'add_meta_boxes', 'fx_topupepin_add_product_image_metabox' );
function fx_topupepin_add_product_image_metabox() {
    add_meta_box(
        'fx_topupepin_image',
        'TopUpEpin изображение',
        'fx_topupepin_image_metabox_cb',
        'product',
        'side',
        'default'
    );
}

function fx_topupepin_image_metabox_cb( $post ) {
    $product_id = $post->ID;

    if ( ! fx_topupepin_is_topupepin_product( $product_id ) ) {
        echo '<p>Этот продукт не из TopUpEpin API (мета <code>_fx_topupepin_product_id</code> отсутствует).</p>';
        return;
    }

    $custom_url = get_post_meta( $product_id, '_fx_topupepin_custom_image_url', true );
    $thumb_id   = get_post_thumbnail_id( $product_id );
    $thumb_url  = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'thumbnail' ) : '';

    echo '<p><strong>Текущий thumbnail:</strong></p>';
    if ( $thumb_url ) {
        echo '<p><img src="' . esc_url( $thumb_url ) . '" style="max-width:100%;height:auto;border:1px solid #ddd;padding:2px;background:#fff;"></p>';
    } else {
        echo '<p><em>Изображение не назначено.</em></p>';
    }

    echo '<hr>';
    echo '<p><strong>Manual URL изображения:</strong></p>';
    echo '<input type="text" id="fx_topupepin_custom_image_url" name="fx_topupepin_custom_image_url" value="' . esc_attr( $custom_url ) . '" style="width:100%;" placeholder="https://...">';
    echo '<p><button type="button" class="button" id="fx_topupepin_choose_image">Выбрать из медиа</button></p>';
    echo '<p class="description">Если вы заполните это поле, при синхронизации изображение не будет меняться автоматически. Чтобы изменить изображение, отредактируйте URL здесь.</p>';

    wp_nonce_field( 'fx_topupepin_save_custom_image', 'fx_topupepin_custom_image_nonce' );
}

add_action( 'save_post_product', 'fx_topupepin_save_product_image_meta' );
function fx_topupepin_save_product_image_meta( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! isset( $_POST['fx_topupepin_custom_image_nonce'] ) ||
         ! wp_verify_nonce( $_POST['fx_topupepin_custom_image_nonce'], 'fx_topupepin_save_custom_image' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( ! fx_topupepin_is_topupepin_product( $post_id ) ) {
        return;
    }

    $url = '';
    if ( isset( $_POST['fx_topupepin_custom_image_url'] ) ) {
        $url = trim( wp_unslash( $_POST['fx_topupepin_custom_image_url'] ) );
    }

    if ( $url === '' ) {
        delete_post_meta( $post_id, '_fx_topupepin_custom_image_url' );
        return;
    }

    $url = esc_url_raw( $url );
    update_post_meta( $post_id, '_fx_topupepin_custom_image_url', $url );

    // Если manual изображение указано – сразу назначить как thumbnail (force = true)
    fx_topupepin_set_product_image_from_url( $post_id, $url, true );
}

/**
 * === WooCommerce SETTINGS / ADMIN ===
 */

add_action( 'admin_menu', 'fx_topupepin_add_admin_menu' );
add_action( 'admin_init', 'fx_topupepin_settings_init' );

function fx_topupepin_add_admin_menu() {
    add_menu_page(
        'TopUpEpin',
        'TopUpEpin',
        'manage_options',
        'fx-topupepin',
        'fx_topupepin_options_page',
        'dashicons-rest-api',
        56
    );
}

function fx_topupepin_settings_init() {

    register_setting( 'fx_topupepin', 'fx_topupepin_api_key' );
    register_setting( 'fx_topupepin', 'fx_topupepin_api_base', array(
        'default' => fx_topupepin_default_base_url(),
    ) );
    register_setting( 'fx_topupepin', 'fx_topupepin_debug' );

    // Курс и маржа
    register_setting( 'fx_topupepin', 'fx_topupepin_rate_usd_azn', array(
        'default' => 1.7,
    ) );

    // NEW: Auto-курс TRY -> AZN (1 = активен, 0 = деактивирован)
    register_setting( 'fx_topupepin', 'fx_topupepin_rate_auto', array(
        'default' => 0,
    ) );

    // NEW: ExchangeRate-API KEY (только для валюты)
    register_setting( 'fx_topupepin', 'fx_topupepin_rate_api_key', array(
        'default' => '',
    ) );

    // NEW: Интервал обновления курса (минуты)
    register_setting( 'fx_topupepin', 'fx_topupepin_rate_update_interval', array(
        'default' => 60, // 60 мин = 1 час
    ) );

    register_setting( 'fx_topupepin', 'fx_topupepin_markup_percent', array(
        'default' => 30,
    ) );

    // Процент скидки
    register_setting( 'fx_topupepin', 'fx_topupepin_sale_discount_percent', array(
        'default' => 0,
    ) );

    // TopUpEpin категория фильтр
    register_setting( 'fx_topupepin', 'fx_topupepin_import_category_filter', array(
        'default' => '',
    ) );

    // Карта изображений категорий
    register_setting( 'fx_topupepin', 'fx_topupepin_category_image_map', array(
        'default' => '',
    ) );

    // === NEW: Карта short description категорий ===
    register_setting( 'fx_topupepin', 'fx_topupepin_category_desc_map', array(
        'default' => '',
    ) );

    // Категория → игровые поля (ID / Zone / Region)
    register_setting( 'fx_topupepin', 'fx_topupepin_category_fields', array(
        'default' => array(),
    ) );

    // NEW: Категория → отдельные маржи
    register_setting( 'fx_topupepin', 'fx_topupepin_category_markups', array(
        'default' => array(),
    ) );

    // NEW: Категории "заморозить название"
    register_setting( 'fx_topupepin', 'fx_topupepin_freeze_title_categories', array(
        'default' => array(),
    ) );

    add_settings_section(
        'fx_topupepin_section_main',
        'Параметры TopUpEpin API',
        '__return_false',
        'fx-topupepin'
    );

    add_settings_field(
        'fx_topupepin_api_base',
        'API Base URL',
        'fx_topupepin_api_base_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    add_settings_field(
        'fx_topupepin_api_key',
        'API Key',
        'fx_topupepin_api_key_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    // === ПОЛЯ КУРСА ===
    add_settings_field(
        'fx_topupepin_rate_usd_azn',
        'Курс валюты TopUpEpin → AZN',
        'fx_topupepin_rate_usd_azn_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    // Auto-курс чекбокс
    add_settings_field(
        'fx_topupepin_rate_auto',
        'TRY → AZN auto-курс',
        'fx_topupepin_rate_auto_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    // NEW: ExchangeRate-API KEY
    add_settings_field(
        'fx_topupepin_rate_api_key',
        'ExchangeRate-API Key (TRY→AZN)',
        'fx_topupepin_rate_api_key_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    // NEW: Интервал обновления
    add_settings_field(
        'fx_topupepin_rate_update_interval',
        'Интервал обновления курса',
        'fx_topupepin_rate_update_interval_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    add_settings_field(
        'fx_topupepin_markup_percent',
        'Маржа (%)',
        'fx_topupepin_markup_percent_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    add_settings_field(
        'fx_topupepin_sale_discount_percent',
        'Скидка (%)',
        'fx_topupepin_sale_discount_percent_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    add_settings_field(
        'fx_topupepin_import_category_filter',
        'Фильтр категорий TopUpEpin',
        'fx_topupepin_import_category_filter_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    add_settings_field(
        'fx_topupepin_category_image_map',
        'Карта изображений категорий',
        'fx_topupepin_category_image_map_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    // Поле short description категории
    add_settings_field(
        'fx_topupepin_category_desc_map',
        'Short description категории',
        'fx_topupepin_category_desc_map_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    add_settings_field(
        'fx_topupepin_category_fields',
        'Игровые поля по категориям',
        'fx_topupepin_category_fields_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );

    add_settings_field(
        'fx_topupepin_debug',
        'Режим отладки',
        'fx_topupepin_debug_render',
        'fx-topupepin',
        'fx_topupepin_section_main'
    );
}


function fx_topupepin_api_base_render() {
    $value = get_option( 'fx_topupepin_api_base', fx_topupepin_default_base_url() );
    echo '<input type="text" name="fx_topupepin_api_base" value="' . esc_attr( $value ) . '" style="width:100%;">';
    echo '<p class="description">По умолчанию: https://topupepin.com/api/v1</p>';
}

function fx_topupepin_api_key_render() {
    $value = get_option( 'fx_topupepin_api_key', '' );
    echo '<input type="text" name="fx_topupepin_api_key" value="' . esc_attr( $value ) . '" style="width:100%;">';
    echo '<p class="description">API key из панели TopUpEpin.</p>';
}

function fx_topupepin_rate_usd_azn_render() {
    $value = get_option( 'fx_topupepin_rate_usd_azn', 1.7 );
    echo '<input type="number" step="0.0001" name="fx_topupepin_rate_usd_azn" value="' . esc_attr( $value ) . '" style="width:100px;">';
    echo '<p class="description">Например: если цены TopUpEpin в TRY, то 1 TRY = X AZN. При активном auto-курсе это значение также показывает последний полученный курс и используется как fallback при проблемах.</p>';
}

// NEW: render auto-курс чекбокс
function fx_topupepin_rate_auto_render() {
    $value = (int) get_option( 'fx_topupepin_rate_auto', 0 );
    ?>
    <label>
        <input type="checkbox" name="fx_topupepin_rate_auto" value="1" <?php checked( 1, $value ); ?>>
        Получать TRY → AZN курс автоматически из внешнего API
    </label>
    <p class="description">
        Если активировать, плагин будет брать курс TRY → AZN с exchangerate.host
        и кэшировать на 1 час. Если API недоступен, будет использоваться manual курс выше.
    </p>
    <?php
}
// NEW: ExchangeRate-API KEY render
function fx_topupepin_rate_api_key_render() {
    $value = get_option( 'fx_topupepin_rate_api_key', '' );
    echo '<input type="text" name="fx_topupepin_rate_api_key" value="' . esc_attr( $value ) . '" style="width:100%;">';
    echo '<p class="description">
        Введите здесь <strong>API Key</strong> вашего аккаунта ExchangeRate-API.
        Этот ключ используется только для получения курса TRY → AZN, не связан с TopUpEpin API.
    </p>';
}

// NEW: интервал обновления render (минуты)
function fx_topupepin_rate_update_interval_render() {
    $value = (int) get_option( 'fx_topupepin_rate_update_interval', 60 );

    $options = array(
        15   => '15 минут',
        30   => '30 минут',
        60   => '1 час',
        180  => '3 часа',
        360  => '6 часов',
        720  => '12 часов',
        1440 => '24 часа',
    );

    echo '<select name="fx_topupepin_rate_update_interval">';
    foreach ( $options as $minutes => $label ) {
        printf(
            '<option value="%d"%s>%s</option>',
            $minutes,
            selected( $value, $minutes, false ),
            esc_html( $label )
        );
    }
    echo '</select>';

    echo '<p class="description">
        При активном auto-курсе курс TRY → AZN будет обновляться с этим интервалом и кэшироваться.
        Например, при выборе 60 мин – каждые 1 час будет запрашиваться новый курс.
    </p>';
}

function fx_topupepin_markup_percent_render() {
    $value = get_option( 'fx_topupepin_markup_percent', 30 );
    echo '<input type="number" step="0.01" name="fx_topupepin_markup_percent" value="' . esc_attr( $value ) . '" style="width:100px;"> %';
    echo '<p class="description">Общая (default) маржа. Если для определенной категории отдельная маржа не установлена в таблице выше, для этой категории будет использоваться это число.</p>';
}

function fx_topupepin_sale_discount_percent_render() {
    $value = get_option( 'fx_topupepin_sale_discount_percent', 0 );
    echo '<input type="number" step="0.01" name="fx_topupepin_sale_discount_percent" value="' . esc_attr( $value ) . '" style="width:100px;"> %';
    echo '<p class="description">Этот процент будет показан как скидка на витрине. Например: 30 = основная цена продукта будет на 30% выше скидочной цены, и WooCommerce покажет её перечеркнутой.</p>';
}

function fx_topupepin_import_category_filter_render() {
    $value = get_option( 'fx_topupepin_import_category_filter', '' );
    echo '<input type="text" name="fx_topupepin_import_category_filter" value="' . esc_attr( $value ) . '" style="width:100%;">';
    echo '<p class="description">Введите одно или несколько названий категорий. Для нескольких разделяйте запятыми.<br>Например:<br><code>PUBG Mobile</code><br><code>PUBG Mobile, Mobile Legends, Valorant</code><br>Если оставить пустым, будут импортированы все продукты.</p>';
}

function fx_topupepin_category_image_map_render() {
    $value = get_option( 'fx_topupepin_category_image_map', '' );

    // Основное хранилище – этот textarea (JS его скроет, но остается как fallback)
    echo '<textarea id="fx_topupepin_category_image_map" name="fx_topupepin_category_image_map" rows="6" style="width:100%;">' . esc_textarea( $value ) . '</textarea>';

    // Здесь появится визуальная таблица
    echo '<div id="fx_topupepin_category_image_builder"></div>';

    echo '<p class="description">
        Каждая строка: Название категории | URL изображения<br>
        Например:<br>
        <code>PUBG Mobile|https://ваш-сайт.com/wp-content/uploads/pubg.jpg</code><br>
        <code>Mobile Legends|https://ваш-сайт.com/wp-content/uploads/mlbb.jpg</code><br>
        При включенном JavaScript выше появится визуальный редактор – впишите категорию и выберите изображение из медиабиблиотеки WordPress, система сохранит в том же формате в этом поле.
    </p>';
}

/**
 * === NEW: Поле short description категории render ===
 */
function fx_topupepin_category_desc_map_render() {
    $value = get_option( 'fx_topupepin_category_desc_map', '' );

    echo '<textarea name="fx_topupepin_category_desc_map" rows="6" style="width:100%;">' . esc_textarea( $value ) . '</textarea>';

    echo '<p class="description">
        Каждая строка: Название категории | короткое описание (short description).<br>
        Этот текст будет использоваться для описания продукта и показываться на странице продукта рядом с игровыми полями.<br>
        Например:<br>
        <code>Blood Strike - GLOBAL|Этот пакет действителен только для аккаунтов GLOBAL сервера.</code><br>
        <code>Blood Strike - MENA|Только для аккаунтов региона MENA.</code><br>
        Для каждой категории – одна строка. Название категории должно совпадать с <code>category</code> из API.
    </p>';
}

/**
 * Игровые поля по категориям + маржа + freeze title render
 */
function fx_topupepin_category_fields_render() {
    $config = get_option( 'fx_topupepin_category_fields', array() );
    if ( ! is_array( $config ) ) {
        $config = array();
    }

    $markups = get_option( 'fx_topupepin_category_markups', array() );
    if ( ! is_array( $markups ) ) {
        $markups = array();
    }

    $freeze_titles = get_option( 'fx_topupepin_freeze_title_categories', array() );
    if ( ! is_array( $freeze_titles ) ) {
        $freeze_titles = array();
    }

    $global_markup = (float) get_option( 'fx_topupepin_markup_percent', 30 );

    $cats = fx_topupepin_get_topupepin_categories();

    if ( empty( $cats ) ) {
        echo '<p class="description">Пока нет продуктов TopUpEpin. Сначала используйте кнопку "Синхронизировать продукты".</p>';
        return;
    }

    echo '<p class="description">
        Для каждой категории:
        <ul>
            <li><strong>Игровые поля:</strong> Какие поля требуются (ID, Zone ID, Region)</li>
            <li><strong>Маржа:</strong> Специальная маржа для этой категории (%) – если оставить пустым, будет использоваться общая маржа (' . esc_html( $global_markup ) . '%)</li>
            <li><strong>Заморозить название:</strong> Не изменять название продуктов в этой категории при синхронизации (название продукта останется таким, каким было при первом создании, последующие синхронизации не изменят его)</li>
        </ul>
    </p>';

    echo '<table class="widefat striped" style="max-width:1100px;">';
    echo '<thead><tr>
            <th>Категория</th>
            <th>User ID</th>
            <th>Zone ID</th>
            <th>Region</th>
            <th>Маржа (%)</th>
            <th>Заморозить название</th>
        </tr></thead><tbody>';

    foreach ( $cats as $cat ) {
        $slug = $cat->slug;
        $name = $cat->name;

        $checked_user   = ! empty( $config[ $slug ]['user_id'] );
        $checked_zone   = ! empty( $config[ $slug ]['zone_id'] );
        $checked_region = ! empty( $config[ $slug ]['region'] );

        $cat_markup = '';
        if ( isset( $markups[ $slug ] ) && $markups[ $slug ] !== '' ) {
            $cat_markup = $markups[ $slug ];
        }

        $checked_freeze = isset( $freeze_titles[ $slug ] );

        echo '<tr>';
        echo '<td>' . esc_html( $name ) . '<br><code>' . esc_html( $slug ) . '</code></td>';
        echo '<td><label><input type="checkbox" name="fx_topupepin_category_fields[' . esc_attr( $slug ) . '][user_id]" value="1" ' . checked( $checked_user, true, false ) . '> ID</label></td>';
        echo '<td><label><input type="checkbox" name="fx_topupepin_category_fields[' . esc_attr( $slug ) . '][zone_id]" value="1" ' . checked( $checked_zone, true, false ) . '> Zone ID</label></td>';
        echo '<td><label><input type="checkbox" name="fx_topupepin_category_fields[' . esc_attr( $slug ) . '][region]" value="1" ' . checked( $checked_region, true, false ) . '> Region</label></td>';
        echo '<td><input type="number" step="0.01"
                        name="fx_topupepin_category_markups[' . esc_attr( $slug ) . ']"
                        value="' . esc_attr( $cat_markup ) . '"
                        style="width:80px;"
                        placeholder="' . esc_attr( $global_markup ) . '"> %</td>';
        echo '<td><label><input type="checkbox" name="fx_topupepin_freeze_title_categories[' . esc_attr( $slug ) . ']" value="1" ' . checked( $checked_freeze, true, false ) . '> Заморозить</label></td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
}

function fx_topupepin_debug_render() {
    $value = (int) get_option( 'fx_topupepin_debug', 0 );
    echo '<label><input type="checkbox" name="fx_topupepin_debug" value="1" ' . checked( 1, $value, false ) . '> Писать в лог-файл (wp-content/uploads/fx-topupepin.log)</label>';
}

/**
 * === ADMIN СТРАНИЦА ===
 */

function fx_topupepin_options_page() {

    $test_result            = null;
    $sync_result            = null;
    $cleanup_result         = null;
    $delete_cats_result     = null;
    $delete_products_result = null;
    $rate_refresh_result    = null; // NEW: для результата

    // GET операции
    
        // GET операции
    if ( isset( $_GET['fx_topupepin_test'] ) && current_user_can( 'manage_options' ) ) {
        $test_result = fx_topupepin_get_profile();
    }

    if ( isset( $_GET['fx_topupepin_sync'] ) && current_user_can( 'manage_options' ) ) {
        $sync_result = fx_topupepin_sync_products();
    }

    if ( isset( $_GET['fx_topupepin_cleanup'] ) && current_user_can( 'manage_options' ) ) {
        $cleanup_result = fx_topupepin_cleanup_products();
    }

    // NEW: manual обновление курса
    if ( isset( $_GET['fx_topupepin_refresh_rate'] ) && current_user_can( 'manage_options' ) ) {
        $rate = fx_topupepin_refresh_rate_now();
        $rate_refresh_result = $rate;
    }

    if ( isset( $_GET['fx_topupepin_test'] ) && current_user_can( 'manage_options' ) ) {
        $test_result = fx_topupepin_get_profile();
    }

    if ( isset( $_GET['fx_topupepin_sync'] ) && current_user_can( 'manage_options' ) ) {
        $sync_result = fx_topupepin_sync_products();
    }

    if ( isset( $_GET['fx_topupepin_cleanup'] ) && current_user_can( 'manage_options' ) ) {
        $cleanup_result = fx_topupepin_cleanup_products();
    }

    // POST: выбранные категории удалить
    if ( isset( $_POST['fx_topupepin_delete_categories_submit'] ) && current_user_can( 'manage_options' ) ) {
        check_admin_referer( 'fx_topupepin_delete_categories' );
        $delete_cats_result = array(
            'deleted' => 0,
            'deleted_images' => 0,
            'errors'  => array(),
        );

        $selected = isset( $_POST['fx_topupepin_delete_cats'] ) ? (array) $_POST['fx_topupepin_delete_cats'] : array();
        $selected = array_map( 'sanitize_text_field', $selected );
        $selected = array_unique( $selected );

        if ( ! empty( $selected ) ) {
            $all_cats = fx_topupepin_get_topupepin_categories();
            $map      = array();
            foreach ( $all_cats as $cat ) {
                $map[ $cat->slug ] = $cat;
            }

            foreach ( $selected as $slug ) {
                if ( ! isset( $map[ $slug ] ) ) {
                    $delete_cats_result['errors'][] = 'Категория не найдена: ' . $slug;
                    continue;
                }
                
                $term = $map[ $slug ];
                
                // Найти все продукты TopUpEpin в этой категории
                $products = get_posts( array(
                    'post_type' => 'product',
                    'posts_per_page' => -1,
                    'post_status' => array( 'publish', 'draft', 'pending', 'private' ),
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'product_cat',
                            'field' => 'term_id',
                            'terms' => $term->term_id,
                        )
                    ),
                    'meta_key' => '_fx_topupepin_product_id',
                    'fields' => 'ids',
                ) );
                
                // Удалить изображения каждого продукта
                foreach ( $products as $product_id ) {
                    if ( fx_topupepin_delete_product_image( $product_id ) ) {
                        $delete_cats_result['deleted_images']++;
                    }
                }
                
                // Удалить категорию
                $res = wp_delete_term( $term->term_id, 'product_cat' );
                if ( is_wp_error( $res ) ) {
                    $delete_cats_result['errors'][] = sprintf(
                        'Категория не удалена (%s): %s',
                        $slug,
                        $res->get_error_message()
                    );
                } else {
                    $delete_cats_result['deleted']++;
                }
            }
        }
    }

    // POST: выбранные TopUpEpin продукты удалить
    if ( isset( $_POST['fx_topupepin_delete_products_submit'] ) && current_user_can( 'manage_options' ) ) {
        check_admin_referer( 'fx_topupepin_delete_products' );
        $delete_products_result = array(
            'deleted' => 0,
            'deleted_images' => 0,
            'errors'  => array(),
        );

        $selected = isset( $_POST['fx_topupepin_delete_products'] ) ? (array) $_POST['fx_topupepin_delete_products'] : array();
        $selected = array_map( 'absint', $selected );
        $selected = array_filter( $selected );

        if ( ! empty( $selected ) ) {
            foreach ( $selected as $pid ) {
                if ( ! fx_topupepin_is_topupepin_product( $pid ) ) {
                    $delete_products_result['errors'][] = 'Продукт не TopUpEpin: ID ' . $pid;
                    continue;
                }
                
                // Сначала удалить изображение
                if ( fx_topupepin_delete_product_image( $pid ) ) {
                    $delete_products_result['deleted_images']++;
                }
                
                // Затем удалить продукт
                wp_trash_post( $pid );
                $delete_products_result['deleted']++;
            }
        }
    }

    ?>
    <div class="wrap">
        <style>
        .fx-topupepin-cards {
            max-width: 1100px;
        }
        .fx-topupepin-card {
            background:#fff;
            border-radius:8px;
            padding:20px 20px 24px;
            margin-bottom:20px;
            border:1px solid #e2e8f0;
            box-shadow:0 1px 3px rgba(15,23,42,0.06);
        }
        .fx-topupepin-card h2 {
            margin-top:0;
        }
        .fx-topupepin-badge {
            display:inline-block;
            padding:2px 8px;
            border-radius:999px;
            background:#2271b1;
            color:#fff;
            font-size:11px;
            line-height:1.6;
            margin-left:8px;
        }
        .fx-topupepin-card p.description {
            margin-top:4px;
            color:#4b5563;
        }
        .fx-topupepin-pre {
            background:#111827;
            color:#e5e7eb;
            padding:15px;
            border-radius:8px;
            max-height:400px;
            overflow:auto;
            font-size:12px;
        }
        .fx-topupepin-pre.fx-pre-green { color:#bbf7d0; }
        .fx-topupepin-pre.fx-pre-cyan { color:#a5f3fc; }
        .fx-topupepin-pre.fx-pre-magenta { color:#f9a8d4; }
        .fx-topupepin-pre.fx-pre-yellow { color:#fef08a; }
        .fx-card-danger {
            border-color:#fecaca;
            box-shadow:0 0 0 1px rgba(248,113,113,0.2);
        }
        .fx-card-danger h2 {
            color:#b91c1c;
        }
        .fx-topupepin-image-table .fx-topupepin-preview {
            width:90px;
            height:90px;
            border-radius:6px;
            overflow:hidden;
            background:#f8fafc;
            display:flex;
            align-items:center;
            justify-content:center;
        }
        .fx-topupepin-image-table .fx-topupepin-preview img {
            max-width:100%;
            max-height:100%;
            display:block;
        }
        .fx-topupepin-image-table .fx-topupepin-preview.fx-empty {
            color:#94a3b8;
            font-size:12px;
        }
        .fx-topupepin-image-actions {
            margin-top:8px;
        }
        .fx-topupepin-row-actions {
            text-align:center;
            vertical-align:middle;
        }
        .fx-topupepin-hidden {
            display:none !important;
        }
        #fx_topupepin_category_image_builder {
            margin-top:8px;
        }
        .fx-topupepin-order-meta h3 {
            margin-top:1em;
        }
        </style>

        <h1>TopUpEpin Интеграция</h1>

        <div class="fx-topupepin-cards">

            <!-- НАСТРОЙКИ -->
            <div class="fx-topupepin-card">
                <h2>API и общие настройки <span class="fx-topupepin-badge">Settings</span></h2>
                <p class="description">
                    Здесь вы можете управлять API base URL, TopUpEpin API key, курсом валюты, маржой, скидкой,
                    изображениями категорий, short description категорий и игровыми полями.
                </p>

                <?php
                // Текущий сохраненный курс и auto статус
                $current_rate   = (float) get_option( 'fx_topupepin_rate_usd_azn', 1.7 );
                $rate_auto_on   = (int) get_option( 'fx_topupepin_rate_auto', 0 );
                $rate_interval  = (int) get_option( 'fx_topupepin_rate_update_interval', 60 );
                $rate_api_key   = get_option( 'fx_topupepin_rate_api_key', '' );
                ?>

                <form action="options.php" method="post">
                    <?php
                    settings_fields( 'fx_topupepin' );
                    do_settings_sections( 'fx-topupepin' );
                    submit_button( __( 'Save Changes', 'fx-topupepin' ) );
                    ?>
                </form>

                <hr>

                <h3>TRY → AZN курс</h3>
                <p class="description">
                    Текущий сохраненный курс: <strong><?php echo esc_html( $current_rate ); ?></strong><br>
                    Auto-курс: <strong><?php echo $rate_auto_on ? 'Активен' : 'Деактивирован'; ?></strong><br>
                    Интервал обновления: <strong><?php echo esc_html( $rate_interval ); ?> мин</strong><br>
                    ExchangeRate-API Key: <strong><?php echo $rate_api_key ? 'Указан' : 'Пустой'; ?></strong>
                </p>

                <p>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=fx-topupepin&fx_topupepin_refresh_rate=1' ) ); ?>"
                       class="button button-secondary">
                        Обновить TRY → AZN курс вручную
                    </a>
                </p>

                <?php if ( ! is_null( $rate_refresh_result ) ) : ?>
                    <p>
                        <strong>Результат manual обновления:</strong>
                        <?php echo esc_html( $rate_refresh_result ); ?> (TRY → AZN)
                    </p>
                <?php endif; ?>
            </div>


            <!-- PROFILE TEST -->
            <div class="fx-topupepin-card">
                <h2>Проверка API (Profile)</h2>
                <p class="description">Этот тест отправляет запрос на endpoint <code>/profile</code> и возвращает баланс, уровень и т.д.</p>
                <p>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=fx-topupepin&fx_topupepin_test=1' ) ); ?>" class="button button-primary">
                        Отправить тестовый запрос
                    </a>
                </p>

                <?php if ( ! is_null( $test_result ) ) : ?>
                    <h3>Результат:</h3>
                    <pre class="fx-topupepin-pre fx-pre-green"><?php
                        if ( is_wp_error( $test_result ) ) {
                            echo esc_html( $test_result->get_error_message() );
                        } else {
                            echo esc_html( print_r( $test_result, true ) );
                        }
                    ?></pre>
                <?php endif; ?>
            </div>

            <!-- SYNC (BATCH) -->
            <div class="fx-topupepin-card">
                <h2>Синхронизировать продукты (batch, без нагрузки на API)</h2>
                <p class="description">
                    Эта кнопка будет получать продукты из TopUpEpin <code>/get-services</code> API
                    страница за страницей (например, по 100 услуг за шаг),
                    чтобы не нагружать API и хостинг и уменьшить ошибки 503.
                </p>
                <p>
                    <button type="button" class="button button-primary" id="fx_topupepin_sync_btn">
                        Синхронизировать продукты (batch)
                    </button>
                </p>
                <pre id="fx_topupepin_sync_status" class="fx-topupepin-pre fx-pre-cyan"></pre>
            </div>

<!-- CLEANUP ALL PRODUCTS -->
            <div class="fx-topupepin-card fx-card-danger">
                <h2>Полностью удалить продукты TopUpEpin (все)</h2>
                <p class="description">
                    Эта кнопка отправляет в корзину только продукты, созданные из TopUpEpin API
                    (те, у которых есть мета <code>_fx_topupepin_product_id</code>).
                    Другие WooCommerce продукты не затрагиваются.
                </p>
                <p>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=fx-topupepin&fx_topupepin_cleanup=1' ) ); ?>"
                       class="button button-secondary"
                       onclick="return confirm('Отправить все продукты TopUpEpin в корзину?');">
                        Удалить продукты TopUpEpin (все)
                    </a>
                </p>

                <?php if ( ! is_null( $cleanup_result ) ) : ?>
                    <h3>Результат очистки:</h3>
                    <pre class="fx-topupepin-pre fx-pre-magenta"><?php
                        if ( is_wp_error( $cleanup_result ) ) {
                            echo esc_html( $cleanup_result->get_error_message() );
                        } else {
                            echo "Удалено продуктов: " . $cleanup_result['deleted'] . "\n";
                            echo "Удалено изображений: " . $cleanup_result['deleted_images'] . "\n";
                            echo "Сообщение: " . $cleanup_result['message'];
                        }
                    ?></pre>
                <?php endif; ?>
            </div>

            <!-- DELETE CATEGORIES -->
            <div class="fx-topupepin-card">
                <h2>Удалить выбранные категории</h2>
                <p class="description">В этом списке только WooCommerce категории, связанные с продуктами TopUpEpin.</p>

                <form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=fx-topupepin' ) ); ?>">
                    <?php wp_nonce_field( 'fx_topupepin_delete_categories' ); ?>
                    <table class="widefat striped" style="max-width:800px;">
                        <thead>
                        <tr>
                            <th style="width:40px;">
                                <input type="checkbox" id="fx_topupepin_select_all_cats" />
                            </th>
                            <th>Категория</th>
                            <th>Slug</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $cats = fx_topupepin_get_topupepin_categories();
                        if ( empty( $cats ) ) {
                            echo '<tr><td colspan="3"><em>Категории TopUpEpin не найдены.</em></td></tr>';
                        } else {
                            foreach ( $cats as $cat ) {
                                echo '<tr>';
                                echo '<td><input type="checkbox" name="fx_topupepin_delete_cats[]" value="' . esc_attr( $cat->slug ) . '"></td>';
                                echo '<td>' . esc_html( $cat->name ) . '</td>';
                                echo '<td><code>' . esc_html( $cat->slug ) . '</code></td>';
                                echo '</tr>';
                            }
                        }
                        ?>
                        </tbody>
                    </table>
                    <p>
                        <button type="submit"
                                name="fx_topupepin_delete_categories_submit"
                                class="button button-secondary"
                                onclick="return confirm('Удалить выбранные категории? (Это отвяжет эти категории от всех продуктов)');">
                            Удалить выбранные категории
                        </button>
                    </p>
                </form>

                <?php if ( ! is_null( $delete_cats_result ) ) : ?>
                    <h3>Результат по категориям:</h3>
                    <pre class="fx-topupepin-pre fx-pre-yellow"><?php
                        echo "Удалено категорий: " . $delete_cats_result['deleted'] . "\n";
                        echo "Удалено изображений: " . $delete_cats_result['deleted_images'] . "\n";
                        echo "Ошибки: " . print_r($delete_cats_result['errors'], true);
                    ?></pre>
                <?php endif; ?>
            </div>

            <!-- DELETE PRODUCTS -->
            <div class="fx-topupepin-card">
                <h2>Удалить выбранные продукты TopUpEpin</h2>
                <p class="description">Здесь показаны только продукты, созданные из TopUpEpin API. Выбранные будут отправлены в корзину.</p>

                <form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=fx-topupepin' ) ); ?>">
                    <?php wp_nonce_field( 'fx_topupepin_delete_products' ); ?>
                    <table class="widefat striped" style="max-width:800px;">
                        <thead>
                        <tr>
                            <th style="width:40px;">
                                <input type="checkbox" id="fx_topupepin_select_all_products" />
                            </th>
                            <th>ID</th>
                            <th>Продукт</th>
                            <th>Категория</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $products = get_posts( array(
                            'post_type'      => 'product',
                            'posts_per_page' => -1,
                            'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
                            'meta_key'       => '_fx_topupepin_product_id',
                            'fields'         => 'ids',
                        ) );

                        if ( empty( $products ) ) {
                            echo '<tr><td colspan="4"><em>Продукты TopUpEpin не найдены.</em></td></tr>';
                        } else {
                            foreach ( $products as $pid ) {
                                $title = get_the_title( $pid );
                                $terms = get_the_terms( $pid, 'product_cat' );
                                $cats_str = '';
                                if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                                    $names = array();
                                    foreach ( $terms as $t ) {
                                        $names[] = $t->name;
                                    }
                                    $cats_str = implode( ', ', $names );
                                }
                                echo '<tr>';
                                echo '<td><input type="checkbox" name="fx_topupepin_delete_products[]" value="' . esc_attr( $pid ) . '"></td>';
                                echo '<td>' . esc_html( $pid ) . '</td>';
                                echo '<td>' . esc_html( $title ) . '</td>';
                                echo '<td>' . esc_html( $cats_str ) . '</td>';
                                echo '</tr>';
                            }
                        }
                        ?>
                        </tbody>
                    </table>
                    <p>
                        <button type="submit"
                                name="fx_topupepin_delete_products_submit"
                                class="button button-secondary"
                                onclick="return confirm('Отправить выбранные продукты TopUpEpin в корзину?');">
                            Удалить выбранные продукты
                        </button>
                    </p>
                </form>

                <?php if ( ! is_null( $delete_products_result ) ) : ?>
                    <h3>Результат по продуктам:</h3>
                    <pre class="fx-topupepin-pre fx-pre-yellow"><?php
                        echo "Удалено продуктов: " . $delete_products_result['deleted'] . "\n";
                        echo "Удалено изображений: " . $delete_products_result['deleted_images'] . "\n";
                        echo "Ошибки: " . print_r($delete_products_result['errors'], true);
                    ?></pre>
                <?php endif; ?>
            </div>

        </div><!-- .fx-topupepin-cards -->
    </div><!-- .wrap -->
    <?php
}

/**
 * Имя категории отфильтровать строкой с помощью помощника
 * - case-insensitive
 * - работает как с полным именем, так и со слагом (pubg-mobile-lite)
 */
function fx_topupepin_category_matches( $service_category, $filter_token ) {
    $service_category = trim( (string) $service_category );
    $filter_token     = trim( (string) $filter_token );

    if ( $service_category === '' || $filter_token === '' ) {
        return false;
    }

    // 1) Просто: filter token в имени категории (case-insensitive)
    if ( stripos( $service_category, $filter_token ) !== false ) {
        return true;
    }

    // 2) Сравнить слаги: "PUBG Mobile Lite" ↔ "pubg-mobile-lite"
    $cat_slug    = sanitize_title( $service_category );
    $token_slug  = sanitize_title( $filter_token );

    if ( $cat_slug !== '' && $cat_slug === $token_slug ) {
        return true;
    }

    return false;
}

/**
 * Проверить, находится ли продукт в категориях "заморозить название"
 */
function fx_topupepin_is_title_frozen_for_product( $product_id ) {
    $freeze_categories = get_option( 'fx_topupepin_freeze_title_categories', array() );
    if ( empty( $freeze_categories ) ) {
        return false;
    }

    $product_cats = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'slugs' ) );
    if ( empty( $product_cats ) || is_wp_error( $product_cats ) ) {
        return false;
    }

    $frozen_slugs = array_keys( $freeze_categories );
    $intersect = array_intersect( $product_cats, $frozen_slugs );

    return ! empty( $intersect );
}

/**
 * === NEW: Страница за страницей синхронизация (для batch) ===
 * В одном AJAX вызове обрабатывается только ОДНА страница (page) и limit услуг.
 *
 * @param int $page  Номер страницы (1,2,3,...)
 * @param int $limit Сколько услуг (продуктов) за страницу
 *
 * @return array|WP_Error
 *   array(
 *     'page'    => (int),
 *     'count'   => (int), // сколько услуг пришло на этой странице
 *     'created' => (int),
 *     'updated' => (int),
 *     'has_more'=> (bool) // true → можно вызывать следующую страницу
 *   )
 */
function fx_topupepin_sync_products_step( $page = 1, $limit = 100 ) {
    if ( ! class_exists( 'WC_Product' ) ) {
        return new WP_Error( 'no_wc', 'WooCommerce не активен.' );
    }

    $page  = max( 1, (int) $page );
    $limit = max( 10, (int) $limit );

    $filter_raw       = trim( get_option( 'fx_topupepin_import_category_filter', '' ) );
    $cat_image_map    = fx_topupepin_get_category_image_map();
    $cat_desc_map     = fx_topupepin_get_category_desc_map();
    $discount_percent = (float) get_option( 'fx_topupepin_sale_discount_percent', 0 );

    // Токены фильтра категорий
    $tokens = array();
    if ( $filter_raw !== '' ) {
        $tokens = preg_split( '/[\r\n,;]+/', $filter_raw );
        $tokens = array_filter( array_map( 'trim', $tokens ) );
        $tokens = array_unique( $tokens );

        fx_topupepin_log(
            'STEP IMPORT FILTER RAW: ' . $filter_raw .
            ' | TOKENS: ' . implode( ', ', $tokens )
        );

        if ( empty( $tokens ) ) {
            $tokens = array( $filter_raw );
        }
    }

    // В этом AJAX вызове берем только ОДНУ страницу
    $response = fx_topupepin_get_products( array(
        'limit' => $limit,
        'page'  => $page,
    ) );

    if ( is_wp_error( $response ) ) {
        return $response;
    }

    if ( empty( $response['data'] ) || ! is_array( $response['data'] ) ) {
        if ( 1 === $page ) {
            return new WP_Error(
                'no_data',
                'В ответе TopUpEpin get-services не найдено data (step mode).'
            );
        }

        return array(
            'page'    => $page,
            'count'   => 0,
            'created' => 0,
            'updated' => 0,
            'has_more'=> false,
        );
    }

    $services = array();

    foreach ( $response['data'] as $service ) {
        if ( empty( $service['id'] ) ) {
            continue;
        }

        $category = isset( $service['category'] ) ? $service['category'] : '';

        // Если есть фильтр категории – применяем как раньше
        if ( ! empty( $tokens ) ) {
            $matched = false;
            foreach ( $tokens as $token ) {
                if ( fx_topupepin_category_matches( $category, $token ) ) {
                    $matched = true;
                    break;
                }
            }

            if ( ! $matched ) {
                continue;
            }
        }

        $services[] = $service;
    }

    if ( empty( $services ) ) {
        return array(
            'page'    => $page,
            'count'   => 0,
            'created' => 0,
            'updated' => 0,
            'has_more'=> ( is_array( $response['data'] ) && count( $response['data'] ) === $limit ),
        );
    }

    $created = 0;
    $updated = 0;

    foreach ( $services as $service ) {

        $service_id = isset( $service['id'] ) ? (int) $service['id'] : 0;
        $name       = isset( $service['name'] ) ? sanitize_text_field( $service['name'] ) : '';
        $category   = isset( $service['category'] ) ? sanitize_text_field( $service['category'] ) : '';
        $api_price  = isset( $service['price'] ) ? (float) $service['price'] : 0;
        $active     = isset( $service['status'] ) ? (bool) $service['status'] : true;

        if ( ! $service_id || ! $name ) {
            continue;
        }

        // ==== ВЫБОР URL ИЗОБРАЖЕНИЯ ====
        $image_url = '';

        if ( ! empty( $service['image_url'] ) ) {
            $image_url = esc_url_raw( $service['image_url'] );
        } elseif ( ! empty( $service['image'] ) ) {
            $image_url = esc_url_raw( $service['image'] );
        } elseif ( ! empty( $service['icon'] ) ) {
            $image_url = esc_url_raw( $service['icon'] );
        } elseif ( ! empty( $service['logo'] ) ) {
            $image_url = esc_url_raw( $service['logo'] );
        } elseif ( ! empty( $service['thumbnail'] ) ) {
            $image_url = esc_url_raw( $service['thumbnail'] );
        }

        if ( ! $image_url && $category ) {
            $image_url = fx_topupepin_get_image_for_category( $category, $cat_image_map );
        }

        $image_url = apply_filters( 'fx_topupepin_resolved_image_url', $image_url, $service, $category, $service_id );

        if ( ! $image_url ) {
            fx_topupepin_log( 'STEP: Изображение не найдено: service_id=' . $service_id . ' category=' . $category );
        }

        $sale_price    = fx_topupepin_calc_wc_price( $api_price, $category );
        $regular_price = $sale_price;

        if ( $discount_percent > 0 ) {
            $regular_price = round( $sale_price * ( 1 + $discount_percent / 100 ), 2 );
        }

        // Short description по категории
        $category_desc      = fx_topupepin_get_desc_for_category( $category, $cat_desc_map );
        $short_desc_default = $name . ( $category ? ' - ' . $category : '' );
        $info_tail          = "\n\nЭтот продукт представляет собой цифровой внутриигровой баланс или код. После оплаты ваш заказ будет обработан системой.";

        if ( $category_desc ) {
            $short_desc = $short_desc_default;
            $full_desc  = $category_desc . $info_tail;
        } else {
            $short_desc = $short_desc_default;
            $full_desc  = $short_desc_default . '.' . $info_tail;
        }

        // Найти существующий продукт
        $existing = get_posts( array(
            'post_type'      => 'product',
            'posts_per_page' => 1,
            'meta_key'       => '_fx_topupepin_product_id',
            'meta_value'     => $service_id,
            'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
            'fields'         => 'ids',
        ) );

        if ( ! empty( $existing ) ) {
            // UPDATE
            $product_id = (int) $existing[0];

            // NEW: Если продукт в категории "заморозить название", название не менять
            $is_title_frozen = fx_topupepin_is_title_frozen_for_product( $product_id );

            if ( ! $is_title_frozen ) {
                // Обновить название и описание
                $update_data = array(
                    'ID'         => $product_id,
                    'post_title' => $short_desc,
                );

                if ( $category_desc ) {
                    $update_data['post_content'] = $full_desc;
                    $update_data['post_excerpt'] = $short_desc;
                }

                wp_update_post( $update_data );
            } else {
                // Название заморожено - название и описание не менять, только логировать
                fx_topupepin_log( 'STEP: Название продукта заморожено (product ' . $product_id . ') - название не обновляется.' );
            }

            // Цену и другие метаданные обновляем в любом случае
            update_post_meta( $product_id, '_regular_price', $regular_price );

            if ( $discount_percent > 0 ) {
                update_post_meta( $product_id, '_sale_price', $sale_price );
                update_post_meta( $product_id, '_price',      $sale_price );
            } else {
                delete_post_meta( $product_id, '_sale_price' );
                update_post_meta( $product_id, '_price',      $regular_price );
            }

            update_post_meta( $product_id, '_fx_topupepin_cost',     $api_price );
            update_post_meta( $product_id, '_fx_topupepin_category', $category );
            update_post_meta( $product_id, '_stock_status',          $active ? 'instock' : 'outofstock' );

            if ( $category_desc && ! $is_title_frozen ) {
                update_post_meta( $product_id, '_fx_topupepin_category_desc', wp_kses_post( $category_desc ) );
            } else {
                delete_post_meta( $product_id, '_fx_topupepin_category_desc' );
            }

            fx_topupepin_assign_category( $product_id, $category );

            if ( $image_url ) {
                fx_topupepin_set_product_image_from_url( $product_id, $image_url );
            }

            $updated++;

        } else {
            // CREATE
            $product_id = wp_insert_post( array(
                'post_type'    => 'product',
                'post_title'   => $short_desc,
                'post_content' => $full_desc,
                'post_excerpt' => $short_desc,
                'post_status'  => 'publish',
            ) );

            if ( ! $product_id || is_wp_error( $product_id ) ) {
                continue;
            }

            wp_set_object_terms( $product_id, 'simple', 'product_type' );

            update_post_meta( $product_id, '_regular_price', $regular_price );

            if ( $discount_percent > 0 ) {
                update_post_meta( $product_id, '_sale_price', $sale_price );
                update_post_meta( $product_id, '_price',      $sale_price );
            } else {
                delete_post_meta( $product_id, '_sale_price' );
                update_post_meta( $product_id, '_price',      $regular_price );
            }

            update_post_meta( $product_id, '_fx_topupepin_cost',       $api_price );
            update_post_meta( $product_id, '_fx_topupepin_product_id', $service_id );
            update_post_meta( $product_id, '_fx_topupepin_category',   $category );
            update_post_meta( $product_id, '_manage_stock',            'no' );
            update_post_meta( $product_id, '_stock_status',            $active ? 'instock' : 'outofstock' );

            if ( $category_desc ) {
                update_post_meta( $product_id, '_fx_topupepin_category_desc', wp_kses_post( $category_desc ) );
            }

            fx_topupepin_assign_category( $product_id, $category );

            if ( $image_url ) {
                fx_topupepin_set_product_image_from_url( $product_id, $image_url );
            }

            $created++;
        }
    }

    $count      = count( $services );
    $raw_count  = is_array( $response['data'] ) ? count( $response['data'] ) : 0;
    $has_more   = ( $raw_count === $limit );

    return array(
        'page'    => $page,
        'count'   => $count,
        'created' => $created,
        'updated' => $updated,
        'has_more'=> $has_more,
    );
}

/**
 * AJAX: страница за страницей синхронизация продуктов (для админки)
 */
add_action( 'wp_ajax_fx_topupepin_sync_step', 'fx_topupepin_sync_step_ajax' );

function fx_topupepin_sync_step_ajax() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Нет разрешения.' ) );
    }

    check_ajax_referer( 'fx_topupepin_sync_step', 'nonce' );

    $page  = isset( $_POST['page'] )  ? (int) $_POST['page']  : 1;
    $limit = isset( $_POST['limit'] ) ? (int) $_POST['limit'] : 100;

    $result = fx_topupepin_sync_products_step( $page, $limit );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( array(
            'message' => $result->get_error_message(),
        ) );
    }

    wp_send_json_success( $result );
}
/**
 * === /service → WooCommerce продукты синхронизация ===
 */

function fx_topupepin_sync_products() {
    if ( ! class_exists( 'WC_Product' ) ) {
        return new WP_Error( 'no_wc', 'WooCommerce не активен.' );
    }

    $filter_raw       = trim( get_option( 'fx_topupepin_import_category_filter', '' ) );
    $cat_image_map    = fx_topupepin_get_category_image_map();
    $cat_desc_map     = fx_topupepin_get_category_desc_map(); // NEW
    $discount_percent = (float) get_option( 'fx_topupepin_sale_discount_percent', 0 );

    $services = array(); // id => service array

    // Разбить фильтр категорий на токены (сохраняем старое поведение)
    $tokens = array();
    if ( $filter_raw !== '' ) {
        $tokens = preg_split( '/[\r\n,;]+/', $filter_raw );
        $tokens = array_filter( array_map( 'trim', $tokens ) );
        $tokens = array_unique( $tokens );

        fx_topupepin_log(
            'IMPORT FILTER RAW: ' . $filter_raw .
            ' | TOKENS: ' . implode( ', ', $tokens )
        );

        if ( empty( $tokens ) ) {
            $tokens = array( $filter_raw );
        }
    }

    /**
     * 1) Все продукты получаем с нового /get-services endpoint страница за страницей
     */
    $page      = 1;
    $limit     = 500; // API максимум
    $max_pages = 200; // для безопасности предел (200 * 500 = 100k продуктов)

    do {
        $response = fx_topupepin_get_products( array(
            'limit' => $limit,
            'page'  => $page,
        ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if ( empty( $response['data'] ) || ! is_array( $response['data'] ) ) {
            if ( $page === 1 ) {
                return new WP_Error(
                    'no_data',
                    'В ответе TopUpEpin get-services не найдено data.'
                );
            }
            break;
        }

        foreach ( $response['data'] as $service ) {
            if ( empty( $service['id'] ) ) {
                continue;
            }

            $category = isset( $service['category'] ) ? $service['category'] : '';

            // Если фильтр не пуст – применяем локальный фильтр категорий
            if ( ! empty( $tokens ) ) {
                $matched = false;
                foreach ( $tokens as $token ) {
                    if ( fx_topupepin_category_matches( $category, $token ) ) {
                        $matched = true;
                        break;
                    }
                }

                if ( ! $matched ) {
                    continue;
                }
            }

            $sid = (int) $service['id'];
            $services[ $sid ] = $service; // если пришел тот же id – остается последняя версия
        }

        $count = count( $response['data'] );
        $page++;
    } while ( $count === $limit && $page <= $max_pages );

    if ( empty( $services ) ) {
        return new WP_Error(
            'no_data',
            'В ответе TopUpEpin get-services не найдено подходящих продуктов. Фильтр категорий: ' . $filter_raw
        );
    }

    $created = 0;
    $updated = 0;

    foreach ( $services as $service ) {

        $service_id = isset( $service['id'] ) ? (int) $service['id'] : 0;
        $name       = isset( $service['name'] ) ? sanitize_text_field( $service['name'] ) : '';
        $category   = isset( $service['category'] ) ? sanitize_text_field( $service['category'] ) : '';
        $api_price  = isset( $service['price'] ) ? (float) $service['price'] : 0;
        $active     = isset( $service['status'] ) ? (bool) $service['status'] : true;

        if ( ! $service_id || ! $name ) {
            continue;
        }

        /**
         * ==== ВЫБОР URL ИЗОБРАЖЕНИЯ ====
         */
        $image_url = '';

        if ( ! empty( $service['image_url'] ) ) {
            $image_url = esc_url_raw( $service['image_url'] );
        } elseif ( ! empty( $service['image'] ) ) {
            $image_url = esc_url_raw( $service['image'] );
        } elseif ( ! empty( $service['icon'] ) ) {
            $image_url = esc_url_raw( $service['icon'] );
        } elseif ( ! empty( $service['logo'] ) ) {
            $image_url = esc_url_raw( $service['logo'] );
        } elseif ( ! empty( $service['thumbnail'] ) ) {
            $image_url = esc_url_raw( $service['thumbnail'] );
        }

        if ( ! $image_url && $category ) {
            $image_url = fx_topupepin_get_image_for_category( $category, $cat_image_map );
        }

        $image_url = apply_filters( 'fx_topupepin_resolved_image_url', $image_url, $service, $category, $service_id );

        if ( ! $image_url ) {
            fx_topupepin_log( 'Изображение не найдено: service_id=' . $service_id . ' category=' . $category );
        }

        $sale_price    = fx_topupepin_calc_wc_price( $api_price, $category );
        $regular_price = $sale_price;

        if ( $discount_percent > 0 ) {
            $regular_price = round( $sale_price * ( 1 + $discount_percent / 100 ), 2 );
        }

        // NEW: short description по категории
        $category_desc      = fx_topupepin_get_desc_for_category( $category, $cat_desc_map );
        $short_desc_default = $name . ( $category ? ' - ' . $category : '' );
        $info_tail          = "\n\nЭтот продукт представляет собой цифровой внутриигровой баланс или код. После оплаты ваш заказ будет обработан системой.";

        if ( $category_desc ) {
            // Заголовок остается прежним, основное описание из карты
            $short_desc = $short_desc_default;
            $full_desc  = $category_desc . $info_tail;
        } else {
            // Старое поведение
            $short_desc = $short_desc_default;
            $full_desc  = $short_desc_default . '.' . $info_tail;
        }

        // Найти существующий продукт
        $existing = get_posts( array(
            'post_type'      => 'product',
            'posts_per_page' => 1,
            'meta_key'       => '_fx_topupepin_product_id',
            'meta_value'     => $service_id,
            'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
            'fields'         => 'ids',
        ) );

        if ( ! empty( $existing ) ) {
            // === UPDATE ===
            $product_id = (int) $existing[0];

            // NEW: Если продукт в категории "заморозить название", название не менять
            $is_title_frozen = fx_topupepin_is_title_frozen_for_product( $product_id );

            if ( ! $is_title_frozen ) {
                // Обновить название и описание
                $update_data = array(
                    'ID'         => $product_id,
                    'post_title' => $short_desc,
                );

                if ( $category_desc ) {
                    $update_data['post_content'] = $full_desc;
                    $update_data['post_excerpt'] = $short_desc;
                }

                wp_update_post( $update_data );
            } else {
                // Название заморожено - название и описание не менять, только логировать
                fx_topupepin_log( 'Название продукта заморожено (product ' . $product_id . ') - название не обновляется.' );
            }

            // Цену и другие метаданные обновляем в любом случае
            update_post_meta( $product_id, '_regular_price', $regular_price );

            if ( $discount_percent > 0 ) {
                update_post_meta( $product_id, '_sale_price', $sale_price );
                update_post_meta( $product_id, '_price',      $sale_price );
            } else {
                delete_post_meta( $product_id, '_sale_price' );
                update_post_meta( $product_id, '_price',      $regular_price );
            }

            update_post_meta( $product_id, '_fx_topupepin_cost',     $api_price );
            update_post_meta( $product_id, '_fx_topupepin_category', $category );
            update_post_meta( $product_id, '_stock_status',          $active ? 'instock' : 'outofstock' );

            // NEW: meta short description категории - только если название не заморожено
            if ( $category_desc && ! $is_title_frozen ) {
                update_post_meta( $product_id, '_fx_topupepin_category_desc', wp_kses_post( $category_desc ) );
            } else {
                delete_post_meta( $product_id, '_fx_topupepin_category_desc' );
            }

            fx_topupepin_assign_category( $product_id, $category );

            if ( $image_url ) {
                fx_topupepin_set_product_image_from_url( $product_id, $image_url );
            }

            $updated++;

        } else {
            // === CREATE ===
            $product_id = wp_insert_post( array(
                'post_type'    => 'product',
                'post_title'   => $short_desc,
                'post_content' => $full_desc,
                'post_excerpt' => $short_desc,
                'post_status'  => 'publish',
            ) );

            if ( ! $product_id || is_wp_error( $product_id ) ) {
                continue;
            }

            wp_set_object_terms( $product_id, 'simple', 'product_type' );

            update_post_meta( $product_id, '_regular_price', $regular_price );

            if ( $discount_percent > 0 ) {
                update_post_meta( $product_id, '_sale_price', $sale_price );
                update_post_meta( $product_id, '_price',      $sale_price );
            } else {
                delete_post_meta( $product_id, '_sale_price' );
                update_post_meta( $product_id, '_price',      $regular_price );
            }

            update_post_meta( $product_id, '_fx_topupepin_cost',       $api_price );
            update_post_meta( $product_id, '_fx_topupepin_product_id', $service_id );
            update_post_meta( $product_id, '_fx_topupepin_category',   $category );
            update_post_meta( $product_id, '_manage_stock',            'no' );
            update_post_meta( $product_id, '_stock_status',            $active ? 'instock' : 'outofstock' );

            // NEW: meta short description категории
            if ( $category_desc ) {
                update_post_meta( $product_id, '_fx_topupepin_category_desc', wp_kses_post( $category_desc ) );
            }

            fx_topupepin_assign_category( $product_id, $category );

            if ( $image_url ) {
                fx_topupepin_set_product_image_from_url( $product_id, $image_url );
            }

            $created++;
        }
    }

    return array(
        'created' => $created,
        'updated' => $updated,
    );
}

/**
 * Очистить продукты TopUpEpin (с удалением изображений)
 */

function fx_topupepin_cleanup_products() {
    if ( ! class_exists( 'WC_Product' ) ) {
        return new WP_Error( 'no_wc', 'WooCommerce не активен.' );
    }

    $products = get_posts( array(
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
        'meta_key'       => '_fx_topupepin_product_id',
        'fields'         => 'ids',
    ) );

    if ( empty( $products ) ) {
        return array(
            'deleted' => 0,
            'deleted_images' => 0,
            'message' => 'Продукты TopUpEpin не найдены.',
        );
    }

    $deleted = 0;
    $deleted_images = 0;

    foreach ( $products as $product_id ) {
        // Сначала удалить изображение
        if ( fx_topupepin_delete_product_image( $product_id ) ) {
            $deleted_images++;
        }
        
        // Затем удалить продукт
        wp_trash_post( $product_id );
        $deleted++;
    }

    return array(
        'deleted' => $deleted,
        'deleted_images' => $deleted_images,
        'message' => sprintf(
            '%d продуктов TopUpEpin отправлено в корзину, %d изображений удалено.',
            $deleted,
            $deleted_images
        ),
    );
}

// ... [Остальной код остается без изменений] ...
/**
 * === CHECKOUT ПОЛЯ: ИГРОВАЯ ИНФОРМАЦИЯ ===
 */

function fx_topupepin_cart_has_topupepin_products() {
    if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
        return false;
    }

    foreach ( WC()->cart->get_cart() as $cart_item ) {
        $product_id = $cart_item['product_id'];
        if ( fx_topupepin_is_topupepin_product( $product_id ) ) {
            return true;
        }
    }

    return false;
}

/**
 * Какие поля требуются на основе корзины
 */
function fx_topupepin_get_required_fields_for_cart() {
    $fields = array(
        'user_id' => false,
        'zone_id' => false,
        'region'  => false,
    );

    if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
        return $fields;
    }

    $config = get_option( 'fx_topupepin_category_fields', array() );
    if ( ! is_array( $config ) ) {
        $config = array();
    }

    $has_any_config = ! empty( $config );

    foreach ( WC()->cart->get_cart() as $cart_item ) {
        $product_id = $cart_item['product_id'];
        if ( ! fx_topupepin_is_topupepin_product( $product_id ) ) {
            continue;
        }

        $terms = get_the_terms( $product_id, 'product_cat' );
        if ( empty( $terms ) || is_wp_error( $terms ) ) {
            continue;
        }

        foreach ( $terms as $term ) {
            $slug = $term->slug;

            if ( isset( $config[ $slug ] ) ) {
                if ( ! empty( $config[ $slug ]['user_id'] ) ) {
                    $fields['user_id'] = true;
                }
                if ( ! empty( $config[ $slug ]['zone_id'] ) ) {
                    $fields['zone_id'] = true;
                }
                if ( ! empty( $config[ $slug ]['region'] ) ) {
                    $fields['region'] = true;
                }
            }
        }
    }

    // Если нет никакой конфигурации, по умолчанию: user_id + zone_id требуются
    if ( ! $has_any_config && fx_topupepin_cart_has_topupepin_products() ) {
        $fields['user_id'] = true;
        $fields['zone_id'] = true;
    }

    return $fields;
}

/**
 * Показать игровые поля в checkout (динамически required)
 * (HOOKS ОТКЛЮЧЕНЫ – форма показывается только на странице продукта)
 */
// add_action( 'woocommerce_after_order_notes', 'fx_topupepin_add_checkout_game_fields' );
function fx_topupepin_add_checkout_game_fields( $checkout ) {

    $fields_needed = fx_topupepin_get_required_fields_for_cart();

    if ( ! $fields_needed['user_id'] && ! $fields_needed['zone_id'] && ! $fields_needed['region'] ) {
        return;
    }

    echo '<div id="fx_topupepin_game_fields"><h3>' . esc_html__( 'Игровая информация', 'fx-topupepin' ) . '</h3>';

    if ( $fields_needed['user_id'] ) {
        woocommerce_form_field( 'fx_topupepin_user_id', array(
            'type'        => 'text',
            'class'       => array( 'form-row-wide' ),
            'label'       => esc_html__( 'ID игрового аккаунта (PUBG UID, MLBB ID и т.д.)', 'fx-topupepin' ),
            'placeholder' => esc_attr__( 'Например: 1234567890', 'fx-topupepin' ),
            'required'    => true,
        ), $checkout->get_value( 'fx_topupepin_user_id' ) );
    }

    if ( $fields_needed['zone_id'] ) {
        woocommerce_form_field( 'fx_topupepin_zone_id', array(
            'type'        => 'text',
            'class'       => array( 'form-row-first' ),
            'label'       => esc_html__( 'Zone ID / Server ID', 'fx-topupepin' ),
            'placeholder' => esc_attr__( 'Например: 1234', 'fx-topupepin' ),
            'required'    => true,
        ), $checkout->get_value( 'fx_topupepin_zone_id' ) );
    }

    if ( $fields_needed['region'] ) {
        woocommerce_form_field( 'fx_topupepin_region', array(
            'type'        => 'text',
            'class'       => array( 'form-row-last' ),
            'label'       => esc_html__( 'Region / Server name', 'fx-topupepin' ),
            'placeholder' => esc_attr__( 'Например: Europe, MENA, Asia...', 'fx-topupepin' ),
            'required'    => true,
        ), $checkout->get_value( 'fx_topupepin_region' ) );
    } else {
        // Region optional глобальное поле (если не отмечено в конфигурации)
        woocommerce_form_field( 'fx_topupepin_region', array(
            'type'        => 'text',
            'class'       => array( 'form-row-last' ),
            'label'       => esc_html__( 'Region / Server name', 'fx-topupepin' ),
            'placeholder' => esc_attr__( 'Например: Europe, MENA, Asia...', 'fx-topupepin' ),
            'required'    => false,
        ), $checkout->get_value( 'fx_topupepin_region' ) );
    }

   
}

/**
 * Проверить поля
 */
// add_action( 'woocommerce_checkout_process', 'fx_topupepin_validate_game_fields' );
function fx_topupepin_validate_game_fields() {
    $fields_needed = fx_topupepin_get_required_fields_for_cart();

    if ( ! $fields_needed['user_id'] && ! $fields_needed['zone_id'] && ! $fields_needed['region'] ) {
        return;
    }

    if ( $fields_needed['user_id'] && empty( $_POST['fx_topupepin_user_id'] ) ) {
        wc_add_notice(
            __( 'Пожалуйста, введите ID игрового аккаунта (PUBG UID, MLBB ID и т.д.).', 'fx-topupepin' ),
            'error'
        );
    }

    if ( $fields_needed['zone_id'] && empty( $_POST['fx_topupepin_zone_id'] ) ) {
        wc_add_notice(
            __( 'Пожалуйста, введите Zone ID / Server ID.', 'fx-topupepin' ),
            'error'
        );
    }

    if ( $fields_needed['region'] && empty( $_POST['fx_topupepin_region'] ) ) {
        wc_add_notice(
            __( 'Пожалуйста, введите Region / Server name.', 'fx-topupepin' ),
            'error'
        );
    }
}

/**
 * Сохранить поля в заказ
 */
// add_action( 'woocommerce_checkout_update_order_meta', 'fx_topupepin_save_game_fields' );
function fx_topupepin_save_game_fields( $order_id ) {

    if ( ! empty( $_POST['fx_topupepin_user_id'] ) ) {
        update_post_meta(
            $order_id,
            '_fx_topupepin_user_id',
            sanitize_text_field( $_POST['fx_topupepin_user_id'] )
        );
    }

    if ( ! empty( $_POST['fx_topupepin_zone_id'] ) ) {
        update_post_meta(
            $order_id,
            '_fx_topupepin_zone_id',
            sanitize_text_field( $_POST['fx_topupepin_zone_id'] )
        );
    }

    if ( ! empty( $_POST['fx_topupepin_region'] ) ) {
        update_post_meta(
            $order_id,
            '_fx_topupepin_region',
            sanitize_text_field( $_POST['fx_topupepin_region'] )
        );
    }

    if ( ! empty( $_POST['fx_topupepin_nickname'] ) ) {
        update_post_meta(
            $order_id,
            '_fx_topupepin_nickname',
            sanitize_text_field( $_POST['fx_topupepin_nickname'] )
        );
    }
}

/**
 * Показать игровую информацию в админ-панели
 */
add_action( 'woocommerce_admin_order_data_after_billing_address', 'fx_topupepin_show_game_fields_admin', 10, 1 );
function fx_topupepin_show_game_fields_admin( $order ) {
    $order_id = $order->get_id();

    $user_id  = get_post_meta( $order_id, '_fx_topupepin_user_id', true );
    $zone_id  = get_post_meta( $order_id, '_fx_topupepin_zone_id', true );
    $region   = get_post_meta( $order_id, '_fx_topupepin_region', true );
    $nickname = get_post_meta( $order_id, '_fx_topupepin_nickname', true );

    if ( ! $user_id && ! $zone_id && ! $region && ! $nickname ) {
        return;
    }

    echo '<div class="fx-topupepin-order-meta">';
    echo '<h3>' . esc_html__( 'TopUpEpin – Игровая информация', 'fx-topupepin' ) . '</h3>';
    echo '<p>';

    if ( $user_id ) {
        echo '<strong>ID:</strong> ' . esc_html( $user_id ) . '<br>';
    }
    if ( $zone_id ) {
        echo '<strong>Zone / Server ID:</strong> ' . esc_html( $zone_id ) . '<br>';
    }
    if ( $region ) {
        echo '<strong>Region / Server name:</strong> ' . esc_html( $region ) . '<br>';
    }
    if ( $nickname ) {
        echo '<strong>Nickname:</strong> ' . esc_html( $nickname ) . '<br>';
    }

    echo '</p></div>';
}

add_action( 'woocommerce_order_status_processing', 'fx_topupepin_send_order_to_topupepin' );
add_action( 'woocommerce_order_status_completed',  'fx_topupepin_send_order_to_topupepin' );

function fx_topupepin_send_order_to_topupepin( $order_id ) {
    // Уже отправляли – выходим
    if ( get_post_meta( $order_id, '_fx_topupepin_order_pushed', true ) ) {
        return;
    }

    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        return;
    }

    // 1) Берём данные из мета заказа (если вдруг где-то руками допишешь)
    $game_user_id = get_post_meta( $order_id, '_fx_topupepin_user_id', true );
    $zone_id      = get_post_meta( $order_id, '_fx_topupepin_zone_id', true );
    $region       = get_post_meta( $order_id, '_fx_topupepin_region', true );
    $nickname     = get_post_meta( $order_id, '_fx_topupepin_nickname', true );

    // 2) Если чего-то не хватает – добираем из мета товаров
    if ( ! $game_user_id || ! $zone_id || ! $region || ! $nickname ) {
        foreach ( $order->get_items() as $item_id => $item ) {
            $product_id = $item->get_product_id();

            if ( ! fx_topupepin_is_topupepin_product( $product_id ) ) {
                continue;
            }

            if ( ! $game_user_id ) {
                $val = $item->get_meta( '_fx_topupepin_user_id', true );
                if ( $val ) {
                    $game_user_id = $val;
                }
            }

            if ( ! $zone_id ) {
                $val = $item->get_meta( '_fx_topupepin_zone_id', true );
                if ( $val ) {
                    $zone_id = $val;
                }
            }

            if ( ! $region ) {
                $val = $item->get_meta( '_fx_topupepin_region', true );
                if ( $val ) {
                    $region = $val;
                }
            }

            if ( ! $nickname ) {
                $val = $item->get_meta( '_fx_topupepin_nickname', true );
                if ( $val ) {
                    $nickname = $val;
                }
            }
        }
    }

    $reference           = $order->get_order_number();
    $has_topupepin_items = false;

    foreach ( $order->get_items() as $item_id => $item ) {
        $product_id = $item->get_product_id();
        $service_id = get_post_meta( $product_id, '_fx_topupepin_product_id', true );

        if ( ! $service_id ) {
            continue;
        }

        $has_topupepin_items = true;

        // Какие поля вообще обязательные для ЭТОГО товара (по его категориям)
        $fields_needed = fx_topupepin_get_required_fields_for_product( $product_id );

        // Берём значения в приоритете: item meta → order meta
        $item_user_id = $item->get_meta( '_fx_topupepin_user_id', true );
        if ( ! $item_user_id ) {
            $item_user_id = $game_user_id;
        }

        $item_zone_id = $item->get_meta( '_fx_topupepin_zone_id', true );
        if ( ! $item_zone_id ) {
            $item_zone_id = $zone_id;
        }

        $item_region = $item->get_meta( '_fx_topupepin_region', true );
        if ( ! $item_region ) {
            $item_region = $region;
        }

        $item_nickname = $item->get_meta( '_fx_topupepin_nickname', true );
        if ( ! $item_nickname ) {
            $item_nickname = $nickname;
        }

        /**
         * 2.1. Если для этого товара по настройкам ID / Zone ОБЯЗАТЕЛЬНЫ,
         *      а пользователь их не указал – этот item НЕ отправляем, но другие могут уйти.
         */
        $skip_item = false;

        if ( $fields_needed['user_id'] && ! $item_user_id ) {
            $order->add_order_note(
                sprintf(
                    'TopUpEpin: для товара (item %d) User ID пустой, этот товар не отправлен в API.',
                    $item_id
                )
            );
            $skip_item = true;
        }

        if ( $fields_needed['zone_id'] && ! $item_zone_id ) {
            $order->add_order_note(
                sprintf(
                    'TopUpEpin: для товара (item %d) Zone ID пустой, этот товар не отправлен в API.',
                    $item_id
                )
            );
            $skip_item = true;
        }

        if ( $skip_item ) {
            continue;
        }

        /**
         * 2.2. Для ваучерных / кодовых услуг, где user_id НЕ обязателен:
         *      по документации TopUpEpin нужно передавать userId = "voucher".
         *      Zone ID для таких услуг не обязателен, но можно подставить "1".
         */
        if ( ! $fields_needed['user_id'] && ! $item_user_id ) {
            $item_user_id = 'voucher';
        }

        if ( ! $fields_needed['zone_id'] && ! $item_zone_id ) {
            $item_zone_id = '1';
        }

        // Кол-во (для ваучеров – обязательно, для остальных можно просто 1+)
        $qty = (int) $item->get_quantity();
        if ( $qty <= 0 ) {
            $qty = 1;
        }

        // your_price – опциональный, можем не отправлять
        $your_price = (float) $item->get_total();

        $params = array(
            'referenceOrderNumber' => $reference . '-' . $item_id,
            'productId'            => (string) $service_id,
            'userId'               => (string) $item_user_id,
            'serverId'             => (string) $item_zone_id,
            'qty'                  => (string) $qty,
            // 'your_price'        => $your_price, // если понадобится по доке
        );

        $response = fx_topupepin_request( 'order', $params );

        if ( is_wp_error( $response ) ) {
            $order->add_order_note(
                sprintf( 'TopUpEpin ERROR (item %d): %s', $item_id, $response->get_error_message() )
            );
        } else {
            if ( isset( $response['status'] ) && $response['status'] && isset( $response['data'] ) ) {
                $data          = $response['data'];
                $status        = isset( $data['status'] ) ? $data['status'] : 'unknown';
                $remoteOrderId = isset( $data['orderId'] ) ? $data['orderId'] : '';

                // --- Пытаемся вытащить код ваучера из разных возможных полей ---
                $voucher_code  = '';
                $possible_keys = array(
                    'serialNumber',
                    'serialnumber',
                    'serial',
                    'code',
                    'voucher',
                    'voucherCode',
                    'pin',
                    'cardNumber',
                    'card',
                    'pinCode',
                    'pin_code',
                );

                foreach ( $possible_keys as $k ) {
                    if ( isset( $data[ $k ] ) && $data[ $k ] !== '' ) {
                        $voucher_code = (string) $data[ $k ];
                        break;
                    }
                }

                // Сохраняем полный ответ по item (как было раньше)
                update_post_meta( $order_id, '_fx_topupepin_item_' . $item_id, $data );

                // Сохраняем ваучер в meta самого товара заказа, чтобы показать клиенту
                if ( $voucher_code ) {
                    // meta конкретного order item
                    wc_update_order_item_meta( $item_id, '_fx_topupepin_voucher', $voucher_code );

                    // и общий массив ваучеров на уровне заказа
                    $all_vouchers = get_post_meta( $order_id, '_fx_topupepin_vouchers', true );
                    if ( ! is_array( $all_vouchers ) ) {
                        $all_vouchers = array();
                    }
                    $all_vouchers[ $item_id ] = $voucher_code;
                    update_post_meta( $order_id, '_fx_topupepin_vouchers', $all_vouchers );
                }

                $order->add_order_note(
                    sprintf(
                        "TopUpEpin SUCCESS (item %d)\nRemote order: %s\nStatus: %s\nSerial/Voucher: %s\nUser ID: %s\nZone ID: %s\nRegion: %s\nNickname: %s",
                        $item_id,
                        $remoteOrderId,
                        $status,
                        $voucher_code,
                        $item_user_id,
                        $item_zone_id,
                        $item_region,
                        $item_nickname
                    )
                );
            } else {
                $order->add_order_note(
                    sprintf(
                        'TopUpEpin unknown response (item %d): %s',
                        $item_id,
                        print_r( $response, true )
                    )
                );
            }
        }
    }

    if ( $has_topupepin_items ) {
        update_post_meta( $order_id, '_fx_topupepin_order_pushed', 1 );
    }
}

/**
 * ============================================================
 *  SINGLE PRODUCT: ИГРОВЫЕ ПОЛЯ (ID / ZONE / REGION / NICKNAME)
 *  + REGION (SERVER-LIST) АВТО ЗАГРУЗКА
 * ============================================================
 */

/**
 * Для данного продукта возвращает, какие поля ТРЕБУЮТСЯ
 * (по конфигурации категории в админке).
 */
function fx_topupepin_get_required_fields_for_product( $product_id ) {
    $fields = array(
        'user_id' => false,
        'zone_id' => false,
        'region'  => false,
    );

    if ( ! $product_id ) {
        return $fields;
    }

    $config = get_option( 'fx_topupepin_category_fields', array() );
    if ( ! is_array( $config ) ) {
        $config = array();
    }

    $has_any_config = ! empty( $config );

    $terms = get_the_terms( $product_id, 'product_cat' );
    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
        foreach ( $terms as $term ) {
            $slug = $term->slug;

            if ( isset( $config[ $slug ] ) ) {
                if ( ! empty( $config[ $slug ]['user_id'] ) ) {
                    $fields['user_id'] = true;
                }
                if ( ! empty( $config[ $slug ]['zone_id'] ) ) {
                    $fields['zone_id'] = true;
                }
                if ( ! empty( $config[ $slug ]['region'] ) ) {
                    $fields['region'] = true;
                }
            }
        }
    }

    // Если нет никакой конфигурации – по умолчанию: user_id + zone_id требуются
    if ( ! $has_any_config && fx_topupepin_is_topupepin_product( $product_id ) ) {
        $fields['user_id'] = true;
        $fields['zone_id'] = true;
    }

    return $fields;
}

/**
 * Показать игровые поля на странице single product
 */
/**
 * Показать игровые поля на странице single product
 */
add_action( 'woocommerce_before_add_to_cart_button', 'fx_topupepin_render_product_fields' );
function fx_topupepin_render_product_fields() {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) {
        return;
    }

    global $product;

    if ( ! $product instanceof WC_Product ) {
        return;
    }

    $product_id = $product->get_id();

    // Только для продуктов TopUpEpin
    if ( ! fx_topupepin_is_topupepin_product( $product_id ) ) {
        return;
    }

    $fields_needed = fx_topupepin_get_required_fields_for_product( $product_id );

    // Если никакие поля не нужны – не показываем вообще
    if ( ! $fields_needed['user_id'] && ! $fields_needed['zone_id'] && ! $fields_needed['region'] ) {
        return;
    }

    // NEW: short description по категории мета
    $category_desc = get_post_meta( $product_id, '_fx_topupepin_category_desc', true );

    echo '<div class="fx-topupepin-product-fields" style="margin-bottom:15px;">';

    // NEW: css только один раз печатать
    static $fx_topupepin_desc_css_printed = false;
    if ( ! $fx_topupepin_desc_css_printed ) {
        $fx_topupepin_desc_css_printed = true;
        echo '<style>
        .fx-topupepin-short-desc{
            margin-bottom:10px;
            padding:8px 10px;
            border-radius:6px;
            background:#f3f4ff;
            font-size:13px;
            line-height:1.5;
        }
        .wm-supercell-field {
            /* Ваши дополнительные стили для полей */
            background-color: #f8f9fa;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 12px 15px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .wm-supercell-field:focus {
            border-color: #007cba;
            box-shadow: 0 0 0 3px rgba(0, 124, 186, 0.2);
            outline: none;
        }
        </style>';
    }

    // NEW: блок short description – рядом с изображением и игровыми полями
    if ( $category_desc ) {
        echo '<div class="fx-topupepin-short-desc">' . wp_kses_post( wpautop( $category_desc ) ) . '</div>';
    }

    echo '<h3>' . esc_html__( '', 'fx-topupepin' ) . '</h3>';

    // ID (только для тех категорий, где отмечено в админке)
    if ( $fields_needed['user_id'] ) {
        woocommerce_form_field( 'fx_topupepin_user_id', array(
            'type'        => 'text',
            'class'       => array( 'form-row-wide', 'wm-supercell-field' ),
            'label'       => esc_html__( 'ID', 'fx-topupepin' ),
            'placeholder' => esc_attr__( 'Введите id', 'fx-topupepin' ),
            'required'    => true,
        ), '' );
    }

    // Zone ID / Server ID (только если активно в конфигурации)
    if ( $fields_needed['zone_id'] ) {
        woocommerce_form_field( 'fx_topupepin_zone_id', array(
            'type'        => 'text',
            'class'       => array( 'form-row-first', 'wm-supercell-field' ),
            'label'       => esc_html__( 'Zone ID / Server ID', 'fx-topupepin' ),
            'placeholder' => esc_attr__( 'Введите zone id', 'fx-topupepin' ),
            'required'    => true,
        ), '' );
    }

    /**
     * Region / Server
     * — ТЕПЕРЬ показывается только у тех продуктов,
     *   для которых в админке для этой категории отмечен чекбокс "Region".
     * Если в конфигурации region OFF – этот select вообще НЕ ПОКАЗЫВАЕТСЯ.
     */
    if ( $fields_needed['region'] ) {

        // Если Zone ID активен → второй столбец, если нет → полная ширина
        $region_class = $fields_needed['zone_id'] ? 'form-row-last' : 'form-row-wide';

        woocommerce_form_field( 'fx_topupepin_region', array(
            'type'        => 'select',
            'class'       => array( $region_class, 'wm-supercell-field' ),
            'label'       => esc_html__( 'Region / Server', 'fx-topupepin' ),
            'required'    => true,
            'options'     => array(
                '' => esc_html__( 'Загрузка...', 'fx-topupepin' ),
            ),
        ), '' );
    }

    // Nickname – optional, всегда
   // woocommerce_form_field( 'fx_topupepin_nickname', array(
     //   'type'        => 'text',
    //    'class'       => array( 'form-row-wide', 'wm-supercell-field' ),
     //   'label'       => esc_html__( 'Nickname / Имя в игре', 'fx-topupepin' ),
      //  'placeholder' => esc_attr__( 'Например: ValyutaMobile', 'fx-topupepin' ),
      //  'required'    => false,
   // ), '' );

  //  echo '</div>';
}

/**
 * Валидация полей на странице продукта (при добавлении в корзину)
 */
add_filter( 'woocommerce_add_to_cart_validation', 'fx_topupepin_validate_product_fields', 10, 3 );
function fx_topupepin_validate_product_fields( $passed, $product_id, $quantity ) {

    if ( ! fx_topupepin_is_topupepin_product( $product_id ) ) {
        return $passed;
    }

    $fields_needed = fx_topupepin_get_required_fields_for_product( $product_id );

    if ( $fields_needed['user_id'] && empty( $_POST['fx_topupepin_user_id'] ) ) {
        wc_add_notice(
            __( 'Пожалуйста, введите ID игрового аккаунта (PUBG UID, MLBB ID и т.д.).', 'fx-topupepin' ),
            'error'
        );
        $passed = false;
    }

    if ( $fields_needed['zone_id'] && empty( $_POST['fx_topupepin_zone_id'] ) ) {
        wc_add_notice(
            __( 'Пожалуйста, введите Zone ID / Server ID.', 'fx-topupepin' ),
            'error'
        );
        $passed = false;
    }

    if ( $fields_needed['region'] && empty( $_POST['fx_topupepin_region'] ) ) {
        wc_add_notice(
            __( 'Пожалуйста, выберите Region / Server.', 'fx-topupepin' ),
            'error'
        );
        $passed = false;
    }

    return $passed;
}

/**
 * Сохранить поля single product в cart item
 */
add_filter( 'woocommerce_add_cart_item_data', 'fx_topupepin_add_cart_item_data', 10, 3 );
function fx_topupepin_add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {

    if ( ! fx_topupepin_is_topupepin_product( $product_id ) ) {
        return $cart_item_data;
    }

    $keys = array(
        'fx_topupepin_user_id',
        'fx_topupepin_zone_id',
        'fx_topupepin_region',
        'fx_topupepin_nickname',
    );

    foreach ( $keys as $key ) {
        if ( isset( $_POST[ $key ] ) && $_POST[ $key ] !== '' ) {
            $cart_item_data[ $key ] = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
        }
    }

    return $cart_item_data;
}

/**
 * Показать игровую информацию в корзине / чекауте
 */
add_filter( 'woocommerce_get_item_data', 'fx_topupepin_display_cart_item_data', 10, 2 );
function fx_topupepin_display_cart_item_data( $item_data, $cart_item ) {

    $map = array(
        'fx_topupepin_user_id'   => __( 'User ID', 'fx-topupepin' ),
        'fx_topupepin_zone_id'   => __( 'Zone ID / Server ID', 'fx-topupepin' ),
        'fx_topupepin_region'    => __( 'Region / Server', 'fx-topupepin' ),
        'fx_topupepin_nickname'  => __( 'Nickname', 'fx-topupepin' ),
    );

    foreach ( $map as $key => $label ) {
        if ( ! empty( $cart_item[ $key ] ) ) {
            $item_data[] = array(
                'name'  => $label,
                'value' => wc_clean( $cart_item[ $key ] ),
            );
        }
    }

    return $item_data;
}

/**
 * Скопировать из cart item в order item + order meta
 * (работает параллельно с существующими checkout мета).
 */
add_action( 'woocommerce_checkout_create_order_line_item', 'fx_topupepin_checkout_create_order_line_item', 10, 4 );
function fx_topupepin_checkout_create_order_line_item( $item, $cart_item_key, $values, $order ) {

    $map = array(
        'fx_topupepin_user_id'   => '_fx_topupepin_user_id',
        'fx_topupepin_zone_id'   => '_fx_topupepin_zone_id',
        'fx_topupepin_region'    => '_fx_topupepin_region',
        'fx_topupepin_nickname'  => '_fx_topupepin_nickname',
    );

    foreach ( $map as $cart_key => $meta_key ) {
        if ( ! empty( $values[ $cart_key ] ) ) {
            $val = $values[ $cart_key ];

            // order item meta
            $item->add_meta_data( $meta_key, $val, true );

            // если order meta еще пустое – заполним (даже если checkout поля не заполнены)
            if ( ! $order->get_meta( $meta_key ) ) {
                $order->update_meta_data( $meta_key, $val );
            }
        }
    }
}

/**
 * На странице single product автозагрузка списка Region (Server) из server-list endpoint
 * с помощью JS + AJAX
 */
add_action( 'wp_enqueue_scripts', 'fx_topupepin_enqueue_product_scripts' );
function fx_topupepin_enqueue_product_scripts() {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) {
        return;
    }

    global $post;

    if ( ! $post ) {
        return;
    }

    $product_id = $post->ID;

    // Только для продукта TopUpEpin
    if ( ! fx_topupepin_is_topupepin_product( $product_id ) ) {
        return;
    }

    wp_enqueue_script( 'jquery' );

    $data = array(
        'ajax_url'   => admin_url( 'admin-ajax.php' ),
        'nonce'      => wp_create_nonce( 'fx_topupepin_product_servers_nonce' ),
        'product_id' => $product_id,
        'choose_one' => __( 'Выберите один', 'fx-topupepin' ),
        'loading'    => __( 'Загрузка регионов...', 'fx-topupepin' ),
        'no_servers' => __( 'Серверы не найдены', 'fx-topupepin' ),
        'error'      => __( 'Ошибка загрузки серверов', 'fx-topupepin' ),
    );

    $js_obj = 'window.fxTopUpEpinProductData = ' . wp_json_encode( $data ) . ';';

    $logic = <<<'JS'
jQuery(function($){
    if (typeof fxTopUpEpinProductData === 'undefined') {
        return;
    }

    var $field = $('select[name="fx_topupepin_region"]');
    if (!$field.length) {
        return;
    }

    $field.prop('disabled', true)
        .html('<option value="">' + (fxTopUpEpinProductData.loading || 'Загрузка...') + '</option>');

    $.post(
        fxTopUpEpinProductData.ajax_url,
        {
            action: 'fx_topupepin_get_product_servers',
            nonce: fxTopUpEpinProductData.nonce,
            product_id: fxTopUpEpinProductData.product_id
        }
    ).done(function(response){
        $field.empty();

        if (response && response.success && response.data && response.data.servers && response.data.servers.length) {
            $field.append(
                $('<option/>', {
                    value: '',
                    text: fxTopUpEpinProductData.choose_one || 'Выберите один'
                })
            );

            response.data.servers.forEach(function(server){
                $field.append(
                    $('<option/>', {
                        value: server.value,
                        text: server.text
                    })
                );
            });
        } else {
            $field.append(
                $('<option/>', {
                    value: '',
                    text: fxTopUpEpinProductData.no_servers || 'Серверы не найдены'
                })
            );
        }

        $field.prop('disabled', false);
    }).fail(function(){
        $field.empty().append(
            $('<option/>', {
                value: '',
                text: fxTopUpEpinProductData.error || 'Ошибка загрузки серверов'
            })
        );
        $field.prop('disabled', false);
    });
});
JS;

    wp_add_inline_script( 'jquery', $js_obj . "\n" . $logic );
}

/**
 * AJAX: Получить server-list для категории продукта
 */
add_action( 'wp_ajax_fx_topupepin_get_product_servers',        'fx_topupepin_get_product_servers_ajax' );
add_action( 'wp_ajax_nopriv_fx_topupepin_get_product_servers', 'fx_topupepin_get_product_servers_ajax' );

function fx_topupepin_get_product_servers_ajax() {
    check_ajax_referer( 'fx_topupepin_product_servers_nonce', 'nonce' );

    $product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
    if ( ! $product_id ) {
        wp_send_json_error( array( 'message' => 'Нет product_id' ) );
    }

    $category = get_post_meta( $product_id, '_fx_topupepin_category', true );
    if ( ! $category ) {
        wp_send_json_error( array( 'message' => 'Нет категории для продукта' ) );
    }

    $api_key = trim( get_option( 'fx_topupepin_api_key', '' ) );
    if ( ! $api_key ) {
        wp_send_json_error( array( 'message' => 'Отсутствует API key' ) );
    }

    // Запрос к endpoint server-list
    $response = fx_topupepin_request( 'server-list', array(
        'category' => $category,
    ) );

    if ( is_wp_error( $response ) ) {
        wp_send_json_error( array( 'message' => $response->get_error_message() ) );
    }

    if ( empty( $response['data'] ) || ! is_array( $response['data'] ) ) {
        wp_send_json_error( array( 'message' => 'Пустой список серверов' ) );
    }

    $servers = array();

    foreach ( $response['data'] as $srv ) {
        if ( isset( $srv['value'], $srv['text'] ) ) {
            $servers[] = array(
                'value' => (string) $srv['value'],
                'text'  => (string) $srv['text'],
            );
        }
    }

    if ( empty( $servers ) ) {
        wp_send_json_error( array( 'message' => 'Не удалось распарсить серверы' ) );
    }

    wp_send_json_success( array( 'servers' => $servers ) );
}

/**
 * Показ кода ваучера в заказе (кабинет клиента, страница "Спасибо", письма)
 */
add_action( 'woocommerce_order_item_meta_end', 'fx_topupepin_show_voucher_to_customer', 10, 4 );
function fx_topupepin_show_voucher_to_customer( $item_id, $item, $order, $plain_text ) {
    $voucher = wc_get_order_item_meta( $item_id, '_fx_topupepin_voucher', true );
    if ( ! $voucher ) {
        return;
    }

    $label = __( 'Voucher / Код', 'fx-topupepin' );

    // В текстовых письмах
    if ( $plain_text ) {
        echo "\n" . $label . ': ' . $voucher;
        return;
    }

    // На фронте (кабинет, страница заказа и т.п.)
    echo '<p class="fx-topupepin-voucher"><strong>' . esc_html( $label ) . ':</strong> ' . esc_html( $voucher ) . '</p>';
}

/**
 * ============================================================
 *  MULTI-CURRENCY ВИЗУАЛЬНОЕ ОТОБРАЖЕНИЕ (ValyutaMobile MultiCurrency)
 *  Только для продуктов TopUpEpin:
 *  - Основная цена остается из WooCommerce (в AZN)
 *  - Под ней показывается примерная сумма в выбранной валюте
 * ============================================================
 */

// На витрине расширить HTML цены (shop, single, архивы)
add_filter( 'woocommerce_get_price_html', 'fx_topupepin_add_multicurrency_price_hint', 20, 2 );
function fx_topupepin_add_multicurrency_price_hint( $price_html, $product ) {

    // Если плагин multi-currency не активен – ничего не делаем
    if (
        ! function_exists( 'vm_mc_convert_price' ) ||
        ! function_exists( 'vm_mc_get_current_currency' ) ||
        ! function_exists( 'vm_mc_get_currency_symbol' )
    ) {
        return $price_html;
    }

    // В админке (редактирование продукта и т.д.) не меняем
    if ( is_admin() && ! wp_doing_ajax() ) {
        return $price_html;
    }

    if ( ! $product instanceof WC_Product ) {
        return $price_html;
    }

    $product_id = $product->get_id();

    // Только для продуктов TopUpEpin (есть мета _fx_topupepin_product_id)
    if ( ! fx_topupepin_is_topupepin_product( $product_id ) ) {
        return $price_html;
    }

    // Если текущая валюта AZN – дополнительная строка не нужна
    $cur_code = vm_mc_get_current_currency();
    if ( strtoupper( $cur_code ) === 'AZN' ) {
        return $price_html;
    }

    // Базовая цена в WooCommerce (в AZN) – sale price или regular price
    $base_price = (float) $product->get_price();
    if ( $base_price <= 0 ) {
        return $price_html;
    }

    // Конвертированная цена в выбранной валюте
    $converted  = vm_mc_convert_price( $base_price );
    $symbol     = vm_mc_get_currency_symbol( $cur_code );
    $decimals   = wc_get_price_decimals();
    $converted_formatted = number_format_i18n( $converted, $decimals );

    // Стиль подсказки: серый, маленький шрифт
    $hint_html = sprintf(
        '<br><small class="fx-topupepin-mc-hint">≈ %s&nbsp;%s</small>',
        esc_html( $converted_formatted ),
        esc_html( $symbol )
    );

    return $price_html . $hint_html;
}

// CSS для frontend (серый мелкий текст)
add_action( 'wp_head', 'fx_topupepin_multicurrency_hint_css' );
function fx_topupepin_multicurrency_hint_css() {
    if ( is_admin() ) {
        return;
    }
    ?>
    <style>
        .fx-topupepin-mc-hint{
            display:inline-block;
            margin-top:2px;
            color:#64748b;
            font-size:12px;
        }
    </style>
    <?php
}